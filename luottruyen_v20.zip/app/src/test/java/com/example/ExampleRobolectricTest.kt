package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.AppSettings
import com.example.data.scraper.MangaScraper
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Lướt Truyện", appName)
  }

  @Test
  fun testScraperOutput() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    AppSettings.init(context)
    
    val testUrl = "https://luottruyen6.com/truyen-tranh/pontus-dem-cuc-da-2-18750"
    println("--- START SCRAPER TEST IN ROBOLECTRIC ---")
    try {
        val list = MangaScraper.getLatestManga(1)
        println("Latest manga count: ${list.size}")
        if (list.isNotEmpty()) {
            val first = list[0]
            println("First Item: Title='${first.title}' Url='${first.url}'")
            
            val detail = MangaScraper.getMangaDetail(first.url)
            println("Detail: Title='${detail.title}' ChaptersCount=${detail.chapters.size}")
            
            if (detail.chapters.isNotEmpty()) {
                val chap = detail.chapters[0]
                println("Testing Chapter: '${chap.name}' Url='${chap.url}'")
                val images = MangaScraper.getChapterImages(chap.url)
                println("Found images: ${images.size}")
                images.take(10).forEachIndexed { index, img ->
                    println("  [$index] $img")
                }
            }
        } else {
            println("SCRAPER returned no items on homepage!")
        }
    } catch (e: Exception) {
        println("SCRAPER TEST FAILED WITH EXCEPTION:")
        e.printStackTrace()
    }
    println("--- END SCRAPER TEST ---")
  }

  @Test
  fun testUserCookieScraping() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    AppSettings.init(context)
    
    // Set the user's actual cookie
    val rawCookie = "ASP.NET_SessionId=l0cfqijn10hf1ygoeatyb5aa;.truyen_AUTH=3538D84D54020B230E846DBDE4CBF51BC19E69332B1B0E51404993E7D28D341E4B9E4C8196B3E573797758F2E21324E96208D270E103DECBBAE36B952CB3322073A9234710923DD0661583FB6F3CCB35DAF9978A7B535A2D5ADFFD2FE76FFC21664972851E3250D0E0732D1257BE142A2CF4B8BA6B9C4EABAEFB3E7478BDC6DCB9F080FD4838D266366FF6A8E35B1B49B673F75E13884C0D590A9A4E28D2E5A43AD9C447D68D508C66F7CB53D140A297F41FFE18AC0426ECE42B3B82C693793258DC1D6C6C691AEEF5D6B97833101C935DA8B16CCF6E5EDC662229635A82DF4C3E9BF7C952303F671F2821DC524345494AD8A6AA433AAA3FB0D5C1B48165C49795A5CCC48F1F89B09FA2732D08E7A9975AD4DEDA45ED7CE48DBAD474D73D54A9150EF03BEB9405E589A9897E26AC711C478354B7F49BF5E376E05C4F3993E85EC06AE352B48B59F2F8CFEF124C184A23E5044066D114EE7056FAD92A39B76655B37FC7B9EB1B747DCBF0D886BE5CEF304E9C77F30A6F77F27AD540A4470B2CCB554542E1EB33E94739739E127683279E47006BD19B40EAC36D9E9D5E09D27CC4DC345337F5E19B2C7D9CB16369F2C9448C5D8F52B5B3BA7439748375D435FA46B3FD211103D424E9C6EF4C9660DBD4CF69C60C64BC024E4F58DDA235375024EB5E6EE25D28B37441ED00724C4FFB2FE12F15AE50B9A752CE1AEC8D911FE1FDDEE9BB42CA14B3E0E08A31CEA6B11061C08E4C1B5DCCC80F27D7FC9020218FEBCB6E17419384BEE2B62C6A6C87AA64DD1F78B547672E0C5BC66F1BBBD31476C4C09F59040D7DD5F2D97889112A7CC35FA65E8E69C51019B4BD98E5DC488E8C8DBF11D0F992453211601B9A01AF2EB62E3C6ECFEE5052D45536C6173A226FB138EE05D63D5D39B28EFC3C1377C27387CF97F92788B7A1B5370BD10BDFDDAAFCF5D40212D543266650B5E2DD5DF4002206CD0DE06BFE24D8EA5AFEC1F6DDD6465F5C87917130B4DF2E2CA062B8A3F21AA01E5A7B05F6B44D42C6BFAA6A0F2CEE6AE9046E3A4F9E771C94876F6DBB3ADB3778;__RequestVerificationToken=g1XMHp0Z6Txy4u4jPeRR-xr1gZC28iVcJE5UidgkIMewydgEioNI4RF5XahW9K17ieXyVf9BDpCXWfA4QygshoHgeSGLCrpSXfpHWjuutCk1;Guid=85ff164d-0294-4a8c-84d1-937753dbc48e;LoginToken=anvsme123@gmail.com;returnUrl=https://luottruyen6.com"
    AppSettings.cookies = rawCookie
    
    println("--- START SCRAPER TEST WITH USER COOKIES ---")
    try {
        // Let's test checking the login account matching the cookie!
        val loginName = MangaScraper.checkLoginStatus()
        println("Verified Login Status Name: '$loginName'")
        
        // Let's test a specific premium/auth-walled chapter.
        val testChapterUrl = "https://luottruyen6.com/truyen-tranh/buon-ban-thoi-tan-the-ta-dung-que-cay-doi-lay-vang/chapter-1/1518331"
        println("Fetching images for Chapter URL: $testChapterUrl")
        val images = MangaScraper.getChapterImages(testChapterUrl)
        println("Images count obtained: ${images.size}")
        if (images.isNotEmpty()) {
            val imgUrl = images[0]
            println("Attempting to download first image: $imgUrl")
            
            val trustAllCerts = object : javax.net.ssl.X509TrustManager {
                override fun checkClientTrusted(chain: Array<out java.security.cert.X509Certificate>?, authType: String?) {}
                override fun checkServerTrusted(chain: Array<out java.security.cert.X509Certificate>?, authType: String?) {}
                override fun getAcceptedIssuers(): Array<java.security.cert.X509Certificate> = arrayOf()
            }
            val sslContext = javax.net.ssl.SSLContext.getInstance("SSL")
            sslContext.init(null, arrayOf<javax.net.ssl.TrustManager>(trustAllCerts), java.security.SecureRandom())
            
            val client = okhttp3.OkHttpClient.Builder()
                .sslSocketFactory(sslContext.socketFactory, trustAllCerts)
                .hostnameVerifier { _, _ -> true }
                .build()
                
            val req = okhttp3.Request.Builder()
                .url(imgUrl)
                .addHeader("Referer", "https://luottruyen6.com/")
                .addHeader("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")
                .build()
                
            client.newCall(req).execute().use { resp ->
                println("Image fetch status code: ${resp.code}")
                println("Image fetch content-type: ${resp.header("Content-Type")}")
                println("Image fetch length: ${resp.body?.contentLength()}")
            }
        }
    } catch (e: Exception) {
        println("COOKIE TEST FAILED WITH EXCEPTION:")
        e.printStackTrace()
    }
    println("--- END SCRAPER TEST WITH USER COOKIES ---")
  }
}
