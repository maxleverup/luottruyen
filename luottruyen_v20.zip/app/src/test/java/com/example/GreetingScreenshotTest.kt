package com.example

import org.junit.Test

class GreetingScreenshotTest {
  @Test
  fun greeting_screenshot() {
    // Deprecated template test
  }
}

