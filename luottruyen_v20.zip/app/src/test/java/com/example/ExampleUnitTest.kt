package com.example

import org.junit.Test
import org.jsoup.Jsoup
import java.net.URLDecoder

class ExampleUnitTest {
    @Test
    fun debugScraper() {
        val url = "https://luottruyen6.com"
        println("=== DEBUG SCRAPER FOR URL: $url ===")
        try {
            val doc = Jsoup.connect(url)
                .userAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")
                .timeout(15000)
                .followRedirects(true)
                .get()
            
            println("Successfully joined page. Title: ${doc.title()}")
            
            // Try default selector
            var elements = doc.select(".items .item, .list-stories .item, div.item, .thumb-item-flow, .story-item, .card-manga, .manga-item-card")
            println("Initial matched elements count: ${elements.size}")
            
            if (elements.isEmpty()) {
                elements = doc.select("div:has(a[href*=/truyen-tranh/]):has(img)")
                println("Fallback matched elements count: ${elements.size}")
            }
            
            var matchedAndNotFiltered = 0
            var filteredOutCount = 0
            
            val filterSelector = ".items-slide, .recommend-comics, .featured-comics, .top-comics, #slider, .col-sidebar, #ctl00_divRight, .right-side, .rightCol, #right-side"
            
            for ((index, element) in elements.take(40).withIndex()) {
                val linkEl = element.selectFirst("a[href*=/truyen-tranh/]:not([href*=/chapter-]):not([href*=/chap-])")
                val href = linkEl?.attr("abs:href") ?: ""
                var title = linkEl?.text()?.trim() ?: ""
                if (title.isEmpty()) {
                    title = element.select("h3, h4, .title, .manga-title").text().trim()
                }
                
                // Show parent line-up
                val parentTags = mutableListOf<String>()
                var p = element.parent()
                while (p != null) {
                    val idPart = if (p.id().isNotEmpty()) "#${p.id()}" else ""
                    val classPart = if (p.className().isNotEmpty()) ".${p.className().replace(" ", ".")}" else ""
                    parentTags.add(p.tagName() + idPart + classPart)
                    p = p.parent()
                }
                
                var isInsideSliderOrSidebar = false
                var parentCheck = element.parent()
                var matchedFilter = ""
                while (parentCheck != null) {
                    if (parentCheck.`is`(filterSelector)) {
                        isInsideSliderOrSidebar = true
                        matchedFilter = parentCheck.tagName() + (if (parentCheck.id().isNotEmpty()) "#${parentCheck.id()}" else "") + (if (parentCheck.className().isNotEmpty()) ".${parentCheck.className().replace(" ", ".")}" else "")
                        break
                    }
                    parentCheck = parentCheck.parent()
                }
                
                if (isInsideSliderOrSidebar) {
                    filteredOutCount++
                    println("[$index] FILTERED OUT BY ancestor ($matchedFilter) | Title: $title | Parents: ${parentTags.take(5).joinToString(" > ")}")
                } else {
                    matchedAndNotFiltered++
                    // Test parsing rating and views
                    var ratingParsed = element.select(".rating-badge").text().trim()
                    if (ratingParsed.isEmpty()) {
                        ratingParsed = element.select(".rating, .score, .star, .star-rating").text().trim()
                    }
                    
                    var viewsParsed = ""
                    val viewEl = element.selectFirst(".view.clearfix, .view")
                    if (viewEl != null) {
                        val spanEl = viewEl.selectFirst("span")
                        viewsParsed = if (spanEl != null) spanEl.text().trim() else viewEl.text().trim()
                    }
                    if (viewsParsed.isEmpty()) {
                        viewsParsed = element.select(".views, .view-count").text().trim()
                    }

                    println("[$index] KEEP | Title: $title | Rating: '$ratingParsed' | Views: '$viewsParsed' | Parents: ${parentTags.take(5).joinToString(" > ")}")
                }
            }
            
            println("=== SUMMARY ===")
            println("Matched and kept: $matchedAndNotFiltered")
            println("Filtered out: $filteredOutCount")
            
            // Now test detail page of the first kept item
            if (elements.isNotEmpty()) {
                val firstKept = elements.firstOrNull { element ->
                    var isInsideSliderOrSidebar = false
                    var parentCheck = element.parent()
                    while (parentCheck != null) {
                        if (parentCheck.`is`(filterSelector)) {
                            isInsideSliderOrSidebar = true
                            break
                        }
                        parentCheck = parentCheck.parent()
                    }
                    !isInsideSliderOrSidebar
                }
                
                if (firstKept != null) {
                    val linkEl = firstKept.selectFirst("a[href*=/truyen-tranh/]:not([href*=/chapter-]):not([href*=/chap-])")
                    val href = linkEl?.attr("abs:href") ?: ""
                    println("\n=== DEBUG DETAILS FOR: $href ===")
                    val detailDoc = Jsoup.connect(href)
                        .userAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")
                        .timeout(15000)
                        .followRedirects(true)
                        .get()
                    
                    println("Detail Page Title: ${detailDoc.title()}")
                    
                    // Let's print all elements that have "itemprop" or class containing rating, aggregate, review, views, etc.
                    println("\n-- Searching for rating elements --")
                    val ratingElements = detailDoc.select("[itemprop*=rating], [itemprop*=Rating], [class*=rating], [id*=rating], [class*=score], [class*=avg], [class*=rate]")
                    for (el in ratingElements.take(30)) {
                        println("Tag: ${el.tagName()} | ID: ${el.id()} | Clan: ${el.className()} | Attrs: ${el.attributes()} | Text: ${el.text().trim()}")
                    }
                    
                    println("\n-- Searching for JSON-LD script tags --")
                    val scriptTags = detailDoc.select("script[type*=json]")
                    for (tag in scriptTags) {
                        val content = tag.html()
                        if (content.contains("ratingValue") || content.contains("aggregateRating") || content.contains("Rating")) {
                            println("JSON-LD Script: $content")
                        }
                    }
                }
            }
            
        } catch (e: Exception) {
            println("Failed to fetch/scrape: Exception: ${e.message}")
            e.printStackTrace()
        }
    }
}











