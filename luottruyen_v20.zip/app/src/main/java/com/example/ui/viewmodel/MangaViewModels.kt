package com.example.ui.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.AppSettings
import com.example.data.model.ChapterItem
import com.example.data.model.FavoriteManga
import com.example.data.model.MangaDetail
import com.example.data.model.MangaItem
import com.example.data.model.ReadingHistory
import com.example.data.repository.MangaRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

// 1. Home ViewModel
class HomeViewModel(private val repository: MangaRepository) : ViewModel() {
    private val _latestMangas = MutableStateFlow<List<MangaItem>>(emptyList())
    val latestMangas: StateFlow<List<MangaItem>> = _latestMangas.asStateFlow()

    private val _searchResults = MutableStateFlow<List<MangaItem>>(emptyList())
    val searchResults: StateFlow<List<MangaItem>> = _searchResults.asStateFlow()

    private val _genres = MutableStateFlow<List<Pair<String, String>>>(emptyList())
    val genres: StateFlow<List<Pair<String, String>>> = _genres.asStateFlow()

    private val _selectedGenre = MutableStateFlow<Pair<String, String>?>(null)
    val selectedGenre: StateFlow<Pair<String, String>?> = _selectedGenre.asStateFlow()

    // --- Bộ lọc (rating, chap, genres) ---
    private val _filterMinRating = MutableStateFlow(AppSettings.filterMinRating)
    val filterMinRating: StateFlow<Float> = _filterMinRating.asStateFlow()

    private val _filterMinChap = MutableStateFlow(AppSettings.filterMinChap)
    val filterMinChap: StateFlow<Int> = _filterMinChap.asStateFlow()

    private val _filterGenres = MutableStateFlow<Set<String>>(AppSettings.filterSelectedGenres)
    val filterGenres: StateFlow<Set<String>> = _filterGenres.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    // isLoading: dùng cho lần tải đầu tiên (hiện full-screen spinner)
    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    // isLoadingMore: dùng cho infinite scroll (hiện loader nhỏ cuối grid)
    private val _isLoadingMore = MutableStateFlow(false)
    val isLoadingMore: StateFlow<Boolean> = _isLoadingMore.asStateFlow()

    // hasMorePages: false khi server trả về rỗng, dừng gọi thêm
    private val _hasMorePages = MutableStateFlow(true)
    val hasMorePages: StateFlow<Boolean> = _hasMorePages.asStateFlow()

    private val _currentPage = MutableStateFlow(1)
    val currentPage: StateFlow<Int> = _currentPage.asStateFlow()

    val favorites: StateFlow<List<FavoriteManga>> = repository.getAllFavorites()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val readingHistory: StateFlow<List<ReadingHistory>> = repository.getReadingHistory()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        loadGenres()
        loadLatest()
    }

    fun loadLatest(page: Int = 1, append: Boolean = false) {
        viewModelScope.launch {
            _isLoading.value = true
            _selectedGenre.value = null
            _currentPage.value = page
            _hasMorePages.value = true
            val results = repository.getLatestManga(page)
            if (append) {
                _latestMangas.value = _latestMangas.value + results
            } else {
                _latestMangas.value = results
            }
            if (results.isEmpty()) _hasMorePages.value = false
            _isLoading.value = false
        }
    }

    fun loadGenres() {
        viewModelScope.launch {
            val liveGenres = repository.getAvailableGenres()
            _genres.value = liveGenres
        }
    }

    fun selectGenre(genre: Pair<String, String>?) {
        viewModelScope.launch {
            _selectedGenre.value = genre
            _hasMorePages.value = true
            if (genre == null) {
                loadLatest(1)
            } else {
                _isLoading.value = true
                _currentPage.value = 1
                val results = repository.getMangaByCategory(genre.second, 1)
                _latestMangas.value = results
                if (results.isEmpty()) _hasMorePages.value = false
                _isLoading.value = false
            }
        }
    }

    fun loadMore(isGenre: Boolean = false) {
        // Không load nếu đang load hoặc đã hết trang
        if (_isLoading.value || _isLoadingMore.value || !_hasMorePages.value) return
        val nextPage = _currentPage.value + 1
        viewModelScope.launch {
            _isLoadingMore.value = true
            try {
                val genre = _selectedGenre.value
                val results = if (genre != null) {
                    repository.getMangaByCategory(genre.second, nextPage)
                } else {
                    repository.getLatestManga(nextPage)
                }
                if (results.isNotEmpty()) {
                    _currentPage.value = nextPage
                    _latestMangas.value = _latestMangas.value + results
                } else {
                    // Hết trang — dừng load vô tận
                    _hasMorePages.value = false
                }
            } catch (e: Exception) {
                // Lỗi mạng — không crash, chỉ dừng load thêm lần này
                android.util.Log.e("HomeViewModel", "loadMore error page $nextPage", e)
            } finally {
                _isLoadingMore.value = false
            }
        }
    }

    fun search(query: String) {
        _searchQuery.value = query
        if (query.isBlank()) {
            _searchResults.value = emptyList()
            return
        }
        viewModelScope.launch {
            _isLoading.value = true
            val results = repository.searchManga(query, 1)
            _searchResults.value = results
            _isLoading.value = false
        }
    }

    fun saveFilters(minRating: Float, minChap: Int, genres: Set<String>) {
        AppSettings.filterMinRating = minRating
        AppSettings.filterMinChap = minChap
        AppSettings.filterSelectedGenres = genres
        _filterMinRating.value = minRating
        _filterMinChap.value = minChap
        _filterGenres.value = genres
    }

    fun resetFilters() {
        AppSettings.resetFilters()
        _filterMinRating.value = 0f
        _filterMinChap.value = 0
        _filterGenres.value = emptySet()
    }

    /** Lọc danh sách manga theo thiết lập bộ lọc hiện tại (client-side) */
    fun applyFilters(list: List<com.example.data.model.MangaItem>): List<com.example.data.model.MangaItem> {
        val minRating = _filterMinRating.value
        val minChap = _filterMinChap.value
        val genres = _filterGenres.value
        return list.filter { manga ->
            // Lọc rating
            val ratingOk = if (minRating <= 0f) true else {
                val r = manga.rating.toFloatOrNull() ?: 0f
                r >= minRating
            }
            // Lọc số chap (latestChapter là "Ch. 123" hoặc "123")
            val chapOk = if (minChap <= 0) true else {
                val raw = manga.latestChapter.replace(Regex("[^\\d]"), "")
                val chapNum = raw.toIntOrNull() ?: 0
                chapNum >= minChap
            }
            // Lọc theo thể loại — nếu không chọn thể loại nào thì không lọc
            // (genre filter ở đây chỉ dùng để lọc thêm phía client khi đã chọn thể loại từ server)
            ratingOk && chapOk
        }
    }

    fun deleteHistoryItem(slug: String) {
        viewModelScope.launch {
            repository.deleteHistoryBySlug(slug)
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            repository.clearHistory()
        }
    }
}

// 2. Detail ViewModel
class DetailViewModel(private val repository: MangaRepository) : ViewModel() {
    private val _mangaDetail = MutableStateFlow<MangaDetail?>(null)
    val mangaDetail: StateFlow<MangaDetail?> = _mangaDetail.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _isFavorite = MutableStateFlow(false)
    val isFavorite: StateFlow<Boolean> = _isFavorite.asStateFlow()

    private val _lastReadChapter = MutableStateFlow<ReadingHistory?>(null)
    val lastReadChapter: StateFlow<ReadingHistory?> = _lastReadChapter.asStateFlow()

    private val _readChapterUrls = MutableStateFlow<Set<String>>(emptySet())
    val readChapterUrls: StateFlow<Set<String>> = _readChapterUrls.asStateFlow()

    fun loadMangaDetail(relativeUrl: String) {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                val detail = repository.getMangaDetail(relativeUrl)
                _mangaDetail.value = detail
                
                val slug = detail.slug
                _isFavorite.value = repository.isFavorite(slug)
                _lastReadChapter.value = repository.getHistoryBySlug(slug)
                _readChapterUrls.value = repository.getReadChapterUrls(slug)
            } catch (e: Exception) {
                Log.e("DetailViewModel", "Could not load detail for $relativeUrl", e)
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun toggleFavorite() {
        val detail = _mangaDetail.value ?: return
        viewModelScope.launch {
            val slug = detail.slug
            if (_isFavorite.value) {
                repository.removeFavoriteBySlug(slug)
                _isFavorite.value = false
            } else {
                val fav = FavoriteManga(
                    slug = slug,
                    url = detail.url,
                    title = detail.title,
                    coverUrl = detail.coverUrl,
                    description = detail.description
                )
                repository.addFavorite(fav)
                _isFavorite.value = true
            }
        }
    }
}

// Model for seamless vertical reader page
data class ReaderPage(
    val imageUrl: String,
    val chapterName: String,
    val chapterUrl: String,
    val pageIndex: Int
)

// 3. Reader ViewModel (Seamless Append - "chap cũ nối chap mới")
class ReaderViewModel(private val repository: MangaRepository) : ViewModel() {
    private val _loadedPages = MutableStateFlow<List<ReaderPage>>(emptyList())
    val loadedPages: StateFlow<List<ReaderPage>> = _loadedPages.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _allChaptersList = MutableStateFlow<List<ChapterItem>>(emptyList())
    val allChaptersList: StateFlow<List<ChapterItem>> = _allChaptersList.asStateFlow()

    private val _currentChapterIndex = MutableStateFlow(-1)
    val currentChapterIndex: StateFlow<Int> = _currentChapterIndex.asStateFlow()

    private val _mangaTitle = MutableStateFlow("")
    val mangaTitle: StateFlow<String> = _mangaTitle.asStateFlow()

    private val _mangaCoverUrl = MutableStateFlow("")
    private val _mangaUrl = MutableStateFlow("")

    private val _readChapterUrls = MutableStateFlow<Set<String>>(emptySet())
    val readChapterUrls: StateFlow<Set<String>> = _readChapterUrls.asStateFlow()

    /**
     * Vị trí scroll ban đầu được khôi phục từ SharedPreferences.
     * -1 = chưa sẵn sàng, >=0 = scroll đến index này ngay khi trang load xong.
     */
    private val _initialScrollIndex = MutableStateFlow(-1)
    val initialScrollIndex: StateFlow<Int> = _initialScrollIndex.asStateFlow()

    fun initReader(chapterUrl: String, mangaTitle: String, mangaCoverUrl: String, mangaUrl: String, chapters: List<ChapterItem>) {
        _mangaTitle.value = mangaTitle
        _mangaCoverUrl.value = mangaCoverUrl
        _mangaUrl.value = mangaUrl
        _loadedPages.value = emptyList()
        
        viewModelScope.launch {
            _isLoading.value = true
            
            val finalChapters = if (chapters.isEmpty()) {
                try {
                    val detailUrlOrSlug = if (mangaUrl.isNotEmpty()) mangaUrl else sortedMangaSlug(chapterUrl)
                    Log.d("ReaderViewModel", "History direct reading detected. Fetching detail page for chapters: $detailUrlOrSlug")
                    val detail = repository.getMangaDetail(detailUrlOrSlug)
                    detail.chapters
                } catch (e: Exception) {
                    Log.e("ReaderViewModel", "Error fetching detail chapters for $chapterUrl", e)
                    emptyList()
                }
            } else {
                chapters
            }
            
            val sortedChapters = sortChaptersChronologically(finalChapters)
            _allChaptersList.value = sortedChapters

            // Load read chapter URLs from DB for chapter list display
            val slug = if (mangaUrl.isNotEmpty()) {
                mangaUrl.substringAfter("luottruyen6.com/").removePrefix("/")
            } else {
                sortedMangaSlug(chapterUrl)
            }
            _readChapterUrls.value = repository.getReadChapterUrls(slug)

            val initialIndex = sortedChapters.indexOfFirst { it.url == chapterUrl }
            val indexToUse = if (initialIndex != -1) initialIndex else sortedChapters.indexOfFirst { it.url.contains(chapterUrl) || chapterUrl.contains(it.url) }
            _currentChapterIndex.value = indexToUse

            if (indexToUse != -1) {
                val chapter = sortedChapters[indexToUse]
                try {
                    val images = repository.getChapterImagesWithOffline(chapter.url, mangaTitle, chapter.name)
                    val readerPages = images.mapIndexed { index, imgUrl ->
                        ReaderPage(
                            imageUrl = imgUrl,
                            chapterName = chapter.name,
                            chapterUrl = chapter.url,
                            pageIndex = index
                        )
                    }
                    _loadedPages.value = readerPages

                    // Khôi phục vị trí từ SharedPreferences nếu trùng chapter
                    val savedPos = AppSettings.getReaderPosition()
                    val savedScrollIndex = if (savedPos != null && savedPos.second == chapter.url) {
                        savedPos.third.coerceIn(0, readerPages.lastIndex.coerceAtLeast(0))
                    } else {
                        0
                    }
                    _initialScrollIndex.value = savedScrollIndex

                    saveProgressToDatabase(chapter)
                } catch (e: Exception) {
                    Log.e("ReaderViewModel", "Error fetching chapter pages for ${chapter.name}", e)
                } finally {
                    _isLoading.value = false
                }
            } else {
                _isLoading.value = false
            }
        }
    }

    private fun sortChaptersChronologically(scrapedChapters: List<ChapterItem>): List<ChapterItem> {
        // Find natural number in name to sort cleanly. E.g., chapter 1, chapter 2.
        return scrapedChapters.sortedWith { c1, c2 ->
            val num1 = extractChapterNumber(c1.name)
            val num2 = extractChapterNumber(c2.name)
            num1.compareTo(num2)
        }
    }

    private fun extractChapterNumber(name: String): Double {
        val cleaned = name.lowercase().replace("chapter", "").replace("chap", "").replace("ch", "").trim()
        val match = Regex("""\d+(\.\d+)?""").find(cleaned)
        return match?.value?.toDoubleOrNull() ?: 0.0
    }

    private fun loadChapterImages(chapter: ChapterItem, clearAll: Boolean) {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                val images = repository.getChapterImagesWithOffline(chapter.url, _mangaTitle.value, chapter.name)
                val readerPages = images.mapIndexed { index, imgUrl ->
                    ReaderPage(
                        imageUrl = imgUrl,
                        chapterName = chapter.name,
                        chapterUrl = chapter.url,
                        pageIndex = index
                    )
                }
                
                if (clearAll) {
                    _loadedPages.value = readerPages
                } else {
                    _loadedPages.value = _loadedPages.value + readerPages
                }
                
                // Save reading history
                saveProgressToDatabase(chapter)
            } catch (e: Exception) {
                Log.e("ReaderViewModel", "Error fetching chapter pages for ${chapter.name}", e)
            } finally {
                _isLoading.value = false
            }
        }
    }

    // Triggered when bottom scroll threshold is reached: "chap cũ nối chap mới" (seamless append)
    fun appendNextChapter() {
        if (_isLoading.value) return
        val nextIndex = _currentChapterIndex.value + 1
        val chapters = _allChaptersList.value
        
        if (nextIndex in chapters.indices) {
            _currentChapterIndex.value = nextIndex
            loadChapterImages(chapters[nextIndex], clearAll = false)
        }
    }

    private suspend fun saveProgressToDatabase(chapter: ChapterItem, pageIndex: Int = 0) {
        val slug = if (_mangaUrl.value.isNotEmpty()) {
            _mangaUrl.value.substringAfter("luottruyen6.com/").removePrefix("/")
        } else {
            sortedMangaSlug(chapter.url)
        }
        val history = ReadingHistory(
            slug = slug,
            title = _mangaTitle.value,
            coverUrl = _mangaCoverUrl.value,
            lastReadChapterName = chapter.name,
            lastReadChapterUrl = chapter.url,
            mangaUrl = _mangaUrl.value,
            lastPageIndex = pageIndex,
            readAt = System.currentTimeMillis()
        )
        repository.saveHistory(history)
        // Mark this chapter as read in per-chapter tracking
        repository.markChapterRead(slug, chapter.url, chapter.name)
        // Update in-memory read set so ChapterListSheet reflects it immediately
        _readChapterUrls.value = _readChapterUrls.value + chapter.url
    }

    /** Job để debounce việc ghi DB — tránh spam database mỗi pixel scroll */
    private var saveDbJob: Job? = null

    /**
     * Gọi mỗi khi user scroll.
     * - SharedPreferences.commit() → ghi NGAY, đồng bộ, không mất khi kill app
     * - DB → debounce 2 giây, tránh spam
     */
    fun savePageProgress(pageIndex: Int) {
        val chapters = _allChaptersList.value
        val curIdx = _currentChapterIndex.value
        if (curIdx !in chapters.indices) return
        val chapter = chapters[curIdx]

        // Tính slug để lưu SharedPreferences
        val slug = if (_mangaUrl.value.isNotEmpty()) {
            _mangaUrl.value.substringAfter("luottruyen6.com/").removePrefix("/")
        } else {
            sortedMangaSlug(chapter.url)
        }

        // Ghi SharedPreferences NGAY LẬP TỨC — an toàn khi kill app
        AppSettings.saveReaderPosition(slug, chapter.url, pageIndex)

        // Ghi DB debounce 2 giây — không spam
        saveDbJob?.cancel()
        saveDbJob = viewModelScope.launch {
            delay(2000)
            saveProgressToDatabase(chapter, pageIndex)
        }
    }

    private fun sortedMangaSlug(url: String): String {
        val path = url.substringAfter("luottruyen6.com/").removePrefix("/")
        
        // Strip chapter suffix (handles formats like "/chapter-...", "-chapter-...", "/chap-...", "-chap-...")
        var clean = path
        for (marker in listOf("/chapter-", "-chapter-", "/chap-", "-chap-", "/chapter", "-chapter", "/chap", "-chap")) {
            if (clean.contains(marker)) {
                clean = clean.substringBefore(marker)
                break
            }
        }
        return clean
    }
}

// 4. Factory
class MangaViewModelFactory(private val repository: MangaRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return when {
            modelClass.isAssignableFrom(HomeViewModel::class.java) -> HomeViewModel(repository) as T
            modelClass.isAssignableFrom(DetailViewModel::class.java) -> DetailViewModel(repository) as T
            modelClass.isAssignableFrom(ReaderViewModel::class.java) -> ReaderViewModel(repository) as T
            else -> throw IllegalArgumentException("Unknown ViewModel class")
        }
    }
}
