package com.example.ui.screens

import android.widget.Toast
import android.content.Context
import java.security.SecureRandom
import java.security.cert.X509Certificate
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager
import okhttp3.OkHttpClient
import coil.ImageLoader
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.SubcomposeAsyncImage
import coil.request.ImageRequest
import com.example.data.model.ChapterItem
import com.example.ui.viewmodel.ReaderPage
import com.example.ui.viewmodel.ReaderViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReaderScreen(
    viewModel: ReaderViewModel,
    mangaTitle: String,
    mangaCoverUrl: String,
    chapterUrl: String,
    mangaUrl: String,
    allChapters: List<ChapterItem>,
    onBackClick: () -> Unit,
    initialPageIndex: Int = 0,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    // Track if we need to scroll to top after chapter change
    var scrollToTopTrigger by remember { mutableStateOf(0) }

    // Initialize the reader values once
    LaunchedEffect(chapterUrl) {
        viewModel.initReader(
            chapterUrl = chapterUrl,
            mangaTitle = mangaTitle,
            mangaCoverUrl = mangaCoverUrl,
            mangaUrl = mangaUrl,
            chapters = allChapters
        )
    }

    val loadedPages by viewModel.loadedPages.collectAsStateWithLifecycle()
    val isLoading by viewModel.isLoading.collectAsStateWithLifecycle()
    val currentChapterIndex by viewModel.currentChapterIndex.collectAsStateWithLifecycle()
    val chaptersList by viewModel.allChaptersList.collectAsStateWithLifecycle()
    val readChapterUrls by viewModel.readChapterUrls.collectAsStateWithLifecycle()
    val initialScrollIndex by viewModel.initialScrollIndex.collectAsStateWithLifecycle()

    var showMenu by remember { mutableStateOf(false) }
    var showChapterList by remember { mutableStateOf(false) }
    val lazyListState = rememberLazyListState()

    // Scroll đến vị trí đã lưu (từ SharedPreferences) ngay khi trang load xong
    // initialScrollIndex được set bởi ViewModel sau khi tính từ SharedPrefs
    var hasScrolledToInitial by remember { mutableStateOf(false) }
    LaunchedEffect(initialScrollIndex, loadedPages) {
        if (!hasScrolledToInitial && initialScrollIndex >= 0 && loadedPages.isNotEmpty()) {
            if (initialScrollIndex > 0) {
                lazyListState.scrollToItem(initialScrollIndex.coerceAtMost(loadedPages.lastIndex))
            }
            hasScrolledToInitial = true
        }
    }

    // Save page position every time user scrolls
    LaunchedEffect(lazyListState) {
        snapshotFlow { lazyListState.firstVisibleItemIndex }
            .collect { pageIndex ->
                viewModel.savePageProgress(pageIndex)
            }
    }

    // Scroll to top when trigger changes
    LaunchedEffect(scrollToTopTrigger) {
        if (scrollToTopTrigger > 0) {
            lazyListState.scrollToItem(0)
        }
    }

    // 1. Detect scrolling near bottom to trigger "chap cũ nối chap mới" (seamless append)
    val shouldTriggerAppend = remember {
        derivedStateOf {
            val totalItems = lazyListState.layoutInfo.totalItemsCount
            val lastVisibleItem = lazyListState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
            totalItems > 0 && lastVisibleItem >= totalItems - 3
        }
    }

    LaunchedEffect(shouldTriggerAppend.value) {
        if (shouldTriggerAppend.value && !isLoading) {
            viewModel.appendNextChapter()
        }
    }

    // 2. Compute current page context based on the first fully visible image on screen
    val activePageInfo = remember {
        derivedStateOf {
            val visibleIndex = lazyListState.firstVisibleItemIndex
            if (visibleIndex in loadedPages.indices) {
                loadedPages[visibleIndex]
            } else {
                null
            }
        }
    }

    // Compute pages that belong to CURRENT chapter only (for progress bar)
    val currentChapterPages = remember(loadedPages, activePageInfo.value) {
        derivedStateOf {
            val activeChapterUrl = activePageInfo.value?.chapterUrl ?: return@derivedStateOf emptyList()
            loadedPages.filter { it.chapterUrl == activeChapterUrl }
        }
    }

    // Current page index within current chapter
    val currentPageInChapter = remember(lazyListState.firstVisibleItemIndex, loadedPages, activePageInfo.value) {
        derivedStateOf {
            val firstVisible = lazyListState.firstVisibleItemIndex
            val activeChapterUrl = activePageInfo.value?.chapterUrl ?: return@derivedStateOf 0
            val pagesInChapter = loadedPages.filter { it.chapterUrl == activeChapterUrl }
            val firstPageIndexInChapter = loadedPages.indexOfFirst { it.chapterUrl == activeChapterUrl }
            if (firstPageIndexInChapter < 0) 0
            else (firstVisible - firstPageIndexInChapter).coerceIn(0, pagesInChapter.lastIndex.coerceAtLeast(0))
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        // Continuous Webtoon scrolling images stack
        if (loadedPages.isEmpty() && isLoading) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
            }
        } else if (loadedPages.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.CloudOff, contentDescription = null, modifier = Modifier.size(48.dp), tint = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("Không lấy được nội dung chương", fontWeight = FontWeight.Bold, color = Color.White)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("Vui lòng tải lại hoặc thử chương khác.", fontSize = 13.sp, color = Color.LightGray)
                    Spacer(modifier = Modifier.height(16.dp))
                    Button(onClick = { viewModel.initReader(chapterUrl, mangaTitle, mangaCoverUrl, mangaUrl, allChapters) }) {
                        Text("Tải Lại")
                    }
                }
            }
        } else {
            LazyColumn(
                state = lazyListState,
                modifier = Modifier
                    .fillMaxSize()
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = { showMenu = !showMenu }
                    )
                    .testTag("reader_viewport_column"),
                contentPadding = PaddingValues(0.dp),
                verticalArrangement = Arrangement.spacedBy(0.dp)
            ) {
                itemsIndexed(loadedPages, key = { index, page -> "${page.chapterUrl}_${page.imageUrl}_$index" }) { index, page ->

                    // Show a beautiful header whenever a new chapter starts in the continuous flow
                    val isFirstPageOfChapter = index == 0 || loadedPages[index - 1].chapterUrl != page.chapterUrl

                    if (isFirstPageOfChapter) {
                        Surface(
                            modifier = Modifier.fillMaxWidth().testTag("chapter_header_label_${page.chapterName.replace(" ", "_").lowercase()}"),
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.25f),
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 12.dp, horizontal = 16.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "--- BẮT ĐẦU: ${page.chapterName.uppercase()} ---",
                                    color = MaterialTheme.colorScheme.primary,
                                    fontWeight = FontWeight.Black,
                                    fontSize = 12.sp,
                                    letterSpacing = 1.sp
                                )
                            }
                        }
                    }

                    // Reader single image page with hotlinking Referer protection
                    MangaPageImage(
                        imgUrl = page.imageUrl,
                        pageIndex = page.pageIndex,
                        chapterName = page.chapterName
                    )

                    // Show a separator after the last page of a chapter
                    val isLastPageOfChapter = index == loadedPages.lastIndex || loadedPages[index + 1].chapterUrl != page.chapterUrl
                    if (isLastPageOfChapter) {
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 14.dp, horizontal = 16.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "HẾT ${page.chapterName.uppercase()}",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Đang nối tiếp chương tiếp theo dưới đây (vuốt tiếp)...",
                                    color = Color.Gray,
                                    fontSize = 10.sp
                                )
                                Icon(
                                    Icons.Default.KeyboardArrowDown,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }

                // Show loading indicator at the bottom when loading next chapters
                if (isLoading) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            CircularProgressIndicator(color = MaterialTheme.colorScheme.primary, modifier = Modifier.size(24.dp))
                        }
                    }
                }
            }
        }

        // Overlay top options drawer
        AnimatedVisibility(
            visible = showMenu,
            enter = slideInVertically(initialOffsetY = { -it }) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { -it }) + fadeOut(),
            modifier = Modifier.align(Alignment.TopCenter)
        ) {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = Color.Black.copy(alpha = 0.9f),
                tonalElevation = 4.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .windowInsetsPadding(WindowInsets.statusBars)
                        .padding(horizontal = 8.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBackClick) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Trở lại", tint = Color.White)
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = mangaTitle,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = Color.White,
                            maxLines = 1
                        )
                        Text(
                            text = activePageInfo.value?.chapterName ?: "Đang tải...",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Overlay bottom quick reader panel (Progress bar + chapter switcher)
        AnimatedVisibility(
            visible = showMenu,
            enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
            modifier = Modifier.align(Alignment.BottomCenter)
        ) {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = Color.Black.copy(alpha = 0.9f),
                tonalElevation = 4.dp
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .windowInsetsPadding(WindowInsets.navigationBars)
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // ===== PROGRESS SCRUBBER BAR (Kotatsu style) =====
                    val totalPagesInChapter = currentChapterPages.value.size
                    val currentPage = currentPageInChapter.value

                    if (totalPagesInChapter > 0) {
                        PageProgressScrubber(
                            totalPages = totalPagesInChapter,
                            currentPage = currentPage,
                            onPageSelected = { targetPage ->
                                val activeChapterUrl = activePageInfo.value?.chapterUrl ?: return@PageProgressScrubber
                                val firstIndexInChapter = loadedPages.indexOfFirst { it.chapterUrl == activeChapterUrl }
                                if (firstIndexInChapter >= 0) {
                                    coroutineScope.launch {
                                        lazyListState.scrollToItem(firstIndexInChapter + targetPage)
                                    }
                                }
                            }
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                    }

                    // ===== CHAPTER NAVIGATION ROW =====
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val hasPrev = currentChapterIndex > 0
                        val hasNext = currentChapterIndex < chaptersList.lastIndex

                        // Prev chapter button
                        IconButton(
                            enabled = hasPrev,
                            onClick = {
                                val prevIndex = currentChapterIndex - 1
                                if (prevIndex in chaptersList.indices) {
                                    viewModel.initReader(
                                        chapterUrl = chaptersList[prevIndex].url,
                                        mangaTitle = mangaTitle,
                                        mangaCoverUrl = mangaCoverUrl,
                                        mangaUrl = mangaUrl,
                                        chapters = allChapters
                                    )
                                    scrollToTopTrigger++
                                    Toast.makeText(context, "Mở: ${chaptersList[prevIndex].name}", Toast.LENGTH_SHORT).show()
                                }
                            }
                        ) {
                            Icon(Icons.Default.SkipPrevious, contentDescription = "Chương trước", tint = if (hasPrev) Color.White else Color.DarkGray)
                        }

                        // Chapter name + chapter list button
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center,
                            modifier = Modifier
                                .clickable(
                                    interactionSource = remember { MutableInteractionSource() },
                                    indication = null,
                                    onClick = { showChapterList = true }
                                )
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            // 3-dash icon to open chapter list
                            Icon(
                                Icons.Default.Menu,
                                contentDescription = "Danh sách chương",
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )

                            Spacer(modifier = Modifier.width(4.dp))

                            Text(
                                text = activePageInfo.value?.chapterName ?: "Cuộn Đọc",
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 14.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        // Next chapter button
                        IconButton(
                            enabled = hasNext,
                            onClick = {
                                val nextIndex = currentChapterIndex + 1
                                if (nextIndex in chaptersList.indices) {
                                    viewModel.initReader(
                                        chapterUrl = chaptersList[nextIndex].url,
                                        mangaTitle = mangaTitle,
                                        mangaCoverUrl = mangaCoverUrl,
                                        mangaUrl = mangaUrl,
                                        chapters = allChapters
                                    )
                                    scrollToTopTrigger++
                                    Toast.makeText(context, "Mở: ${chaptersList[nextIndex].name}", Toast.LENGTH_SHORT).show()
                                }
                            }
                        ) {
                            Icon(Icons.Default.SkipNext, contentDescription = "Chương tiếp theo", tint = if (hasNext) Color.White else Color.DarkGray)
                        }
                    }
                }
            }
        }

        // ===== CHAPTER LIST BOTTOM SHEET =====
        if (showChapterList) {
            ChapterListSheet(
                chapters = chaptersList,
                currentChapterIndex = currentChapterIndex,
                readChapterUrls = readChapterUrls,
                onChapterSelected = { selectedChapter ->
                    showChapterList = false
                    viewModel.initReader(
                        chapterUrl = selectedChapter.url,
                        mangaTitle = mangaTitle,
                        mangaCoverUrl = mangaCoverUrl,
                        mangaUrl = mangaUrl,
                        chapters = allChapters
                    )
                    scrollToTopTrigger++
                },
                onDismiss = { showChapterList = false }
            )
        }
    }
}

// ===== PROGRESS SCRUBBER (Kotatsu-style horizontal progress bar) =====
@Composable
fun PageProgressScrubber(
    totalPages: Int,
    currentPage: Int,
    onPageSelected: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    var barWidthPx by remember { mutableStateOf(0f) }
    var isDragging by remember { mutableStateOf(false) }
    var dragPage by remember { mutableStateOf(currentPage) }

    val displayPage = if (isDragging) dragPage else currentPage

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(28.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(Color.White.copy(alpha = 0.08f))
            .onGloballyPositioned { coords ->
                barWidthPx = coords.size.width.toFloat()
            }
            .pointerInput(totalPages, barWidthPx) {
                detectHorizontalDragGestures(
                    onDragStart = { offset ->
                        isDragging = true
                        if (barWidthPx > 0 && totalPages > 1) {
                            dragPage = ((offset.x / barWidthPx) * (totalPages - 1))
                                .toInt()
                                .coerceIn(0, totalPages - 1)
                        }
                    },
                    onHorizontalDrag = { _, dragAmount ->
                        if (barWidthPx > 0 && totalPages > 1) {
                            val delta = (dragAmount / barWidthPx) * (totalPages - 1)
                            dragPage = (dragPage + delta.toInt()).coerceIn(0, totalPages - 1)
                        }
                    },
                    onDragEnd = {
                        isDragging = false
                        onPageSelected(dragPage)
                    },
                    onDragCancel = {
                        isDragging = false
                    }
                )
            }
    ) {
        // Render vertical tick marks for each page
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 2.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(1.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            for (i in 0 until totalPages) {
                val isActive = i <= displayPage
                val isCurrentExact = i == displayPage
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight(if (isCurrentExact) 1f else 0.6f)
                        .clip(RoundedCornerShape(1.dp))
                        .background(
                            when {
                                isCurrentExact -> MaterialTheme.colorScheme.primary
                                isActive -> MaterialTheme.colorScheme.primary.copy(alpha = 0.7f)
                                else -> Color.White.copy(alpha = 0.2f)
                            }
                        )
                )
            }
        }

        // Page number tooltip
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(end = 4.dp),
            contentAlignment = Alignment.CenterEnd
        ) {
            Text(
                text = "${displayPage + 1}/$totalPages",
                fontSize = 9.sp,
                color = Color.White.copy(alpha = 0.7f),
                fontWeight = FontWeight.Bold
            )
        }
    }
}

// ===== CHAPTER LIST BOTTOM SHEET =====
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChapterListSheet(
    chapters: List<ChapterItem>,
    currentChapterIndex: Int,
    readChapterUrls: Set<String> = emptySet(),
    onChapterSelected: (ChapterItem) -> Unit,
    onDismiss: () -> Unit
) {
    val listState = rememberLazyListState()

    // Auto-scroll to current chapter when sheet opens
    LaunchedEffect(currentChapterIndex) {
        if (currentChapterIndex >= 0 && chapters.isNotEmpty()) {
            listState.scrollToItem(currentChapterIndex.coerceAtMost(chapters.lastIndex))
        }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF1A1A1A),
        dragHandle = {
            Box(
                modifier = Modifier
                    .padding(vertical = 8.dp)
                    .size(width = 40.dp, height = 4.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(Color.White.copy(alpha = 0.3f))
            )
        }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 24.dp)
        ) {
            // Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    Icons.Default.Menu,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Danh sách chương",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = Color.White
                )
                Spacer(modifier = Modifier.weight(1f))
                Text(
                    text = "${chapters.size} chương",
                    fontSize = 12.sp,
                    color = Color.Gray
                )
            }

            Divider(color = Color.White.copy(alpha = 0.1f), thickness = 0.5.dp)

            androidx.compose.foundation.lazy.LazyColumn(
                state = listState,
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 480.dp),
                contentPadding = PaddingValues(vertical = 4.dp)
            ) {
                itemsIndexed(chapters) { index, chapter ->
                    val isCurrent = index == currentChapterIndex
                    val isRead = chapter.url in readChapterUrls
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onChapterSelected(chapter) }
                            .background(
                                if (isCurrent) MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
                                else Color.Transparent
                            )
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (isCurrent) {
                            Icon(
                                Icons.Default.PlayArrow,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                        } else {
                            Spacer(modifier = Modifier.width(20.dp))
                        }
                        Text(
                            text = chapter.name,
                            fontSize = 14.sp,
                            color = if (isCurrent) MaterialTheme.colorScheme.primary else Color.White,
                            fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                        if (isRead) {
                            Spacer(modifier = Modifier.width(8.dp))
                            Icon(
                                Icons.Default.CheckCircle,
                                contentDescription = "Đã đọc",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Đã đọc",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                    if (index < chapters.lastIndex) {
                        Divider(
                            modifier = Modifier.padding(horizontal = 16.dp),
                            color = Color.White.copy(alpha = 0.05f),
                            thickness = 0.5.dp
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun MangaPageImage(
    imgUrl: String,
    pageIndex: Int,
    chapterName: String
) {
    val context = LocalContext.current
    var retryTrigger by remember { mutableStateOf(0) }

    val imageRequest = remember(imgUrl, retryTrigger) {
        val isOffline = imgUrl.startsWith("file://")
        val builder = ImageRequest.Builder(context)
            .data(imgUrl)
            .crossfade(true)
        if (!isOffline) {
            val refererUrl = com.example.data.AppSettings.baseUrl.let { if (it.endsWith("/")) it else "$it/" }
            builder.addHeader("Referer", refererUrl)
            builder.addHeader("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")
        }
        builder.build()
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .wrapContentHeight()
            .background(Color.Black),
        contentAlignment = Alignment.Center
    ) {
        SubcomposeAsyncImage(
            model = imageRequest,
            imageLoader = getTrustingImageLoader(context),
            contentDescription = "Trang ${pageIndex + 1} - $chapterName",
            modifier = Modifier
                .fillMaxWidth()
                .wrapContentHeight(),
            contentScale = ContentScale.FillWidth,
            loading = {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(280.dp),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f),
                        modifier = Modifier.size(24.dp)
                    )
                }
            },
            error = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(260.dp)
                        .background(Color.DarkGray.copy(alpha = 0.2f)),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(Icons.Default.BrokenImage, contentDescription = "Lỗi ảnh", modifier = Modifier.size(36.dp), tint = Color.Gray)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Không tải được trang ${pageIndex + 1}", fontSize = 12.sp, color = Color.Gray)
                    Spacer(modifier = Modifier.height(10.dp))
                    Button(
                        onClick = {
                            retryTrigger++
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.2f))
                    ) {
                        Text("Tải lại trang", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        )
    }
}

private var trustingImageLoader: ImageLoader? = null
private val ReaderScreenPrivateLock = Any()

fun getTrustingImageLoader(context: Context): ImageLoader {
    return trustingImageLoader ?: synchronized(ReaderScreenPrivateLock) {
        trustingImageLoader ?: run {
            val trustAllCerts = object : X509TrustManager {
                override fun checkClientTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
                override fun checkServerTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
                override fun getAcceptedIssuers(): Array<X509Certificate> = arrayOf()
            }

            val sslContext = SSLContext.getInstance("SSL")
            sslContext.init(null, arrayOf<TrustManager>(trustAllCerts), SecureRandom())

            val client = OkHttpClient.Builder()
                .sslSocketFactory(sslContext.socketFactory, trustAllCerts)
                .hostnameVerifier { _, _ -> true }
                .build()

            ImageLoader.Builder(context.applicationContext)
                .okHttpClient(client)
                .build()
        }.also { trustingImageLoader = it }
    }
}
