package com.example.ui.navigation

import android.net.Uri
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.example.data.AppSettings
import com.example.data.repository.MangaRepository
import com.example.ui.screens.DetailScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.ReaderScreen
import com.example.ui.viewmodel.DetailViewModel
import com.example.ui.viewmodel.HomeViewModel
import com.example.ui.viewmodel.MangaViewModelFactory
import com.example.ui.viewmodel.ReaderViewModel

@Composable
fun AppNavGraph(
    navController: NavHostController,
    repository: MangaRepository,
    modifier: Modifier = Modifier
) {
    // Track whether home should auto-open settings (triggered when user is not logged in)
    var openSettingsOnHome by remember { mutableStateOf(false) }

    NavHost(
        navController = navController,
        startDestination = "home",
        modifier = modifier
    ) {
        // 1. Home Screen Route
        composable("home") {
            val factory = MangaViewModelFactory(repository)
            val homeViewModel: HomeViewModel = androidx.lifecycle.viewmodel.compose.viewModel(factory = factory)

            HomeScreen(
                viewModel = homeViewModel,
                openSettingsOnLaunch = openSettingsOnHome,
                onNavigateToDetail = { rawSlug ->
                    openSettingsOnHome = false
                    val cleanSlug = rawSlug.substringAfter("luottruyen6.com/").removePrefix("/")
                    val encodedSlug = Uri.encode(cleanSlug)
                    navController.navigate("detail/$encodedSlug")
                },
                onNavigateToReader = { title, coverUrl, chapterUrl, mangaUrl ->
                    openSettingsOnHome = false
                    val encTitle = Uri.encode(title)
                    val encCover = Uri.encode(coverUrl)
                    val encChapter = Uri.encode(chapterUrl)
                    val encMangaUrl = Uri.encode(mangaUrl)
                    navController.navigate("reader?mangaTitle=$encTitle&mangaCoverUrl=$encCover&chapterUrl=$encChapter&mangaUrl=$encMangaUrl")
                }
            )
        }

        // 2. Detail Screen Route
        composable(
            route = "detail/{slug}",
            arguments = listOf(
                navArgument("slug") { type = NavType.StringType }
            )
        ) { backStackEntry ->
            val encodedSlug = backStackEntry.arguments?.getString("slug") ?: ""
            val slug = Uri.decode(encodedSlug)

            val factory = MangaViewModelFactory(repository)
            val detailViewModel: DetailViewModel = androidx.lifecycle.viewmodel.compose.viewModel(factory = factory)

            DetailScreen(
                viewModel = detailViewModel,
                mangaUrlSlug = slug,
                onBackClick = { navController.popBackStack() },
                onReadChapterClick = { chapterItem ->
                    // ===== LOGIN GATE =====
                    val isLoggedIn = AppSettings.loggedInUserName.isNotEmpty()
                    if (!isLoggedIn) {
                        openSettingsOnHome = true
                        navController.navigate("home") {
                            popUpTo("home") { inclusive = true }
                        }
                        return@DetailScreen
                    }

                    val detail = detailViewModel.mangaDetail.value
                    if (detail != null) {
                        val encTitle = Uri.encode(detail.title)
                        val encCover = Uri.encode(detail.coverUrl)
                        val encChapterUrl = Uri.encode(chapterItem.url)
                        val encMangaUrl = Uri.encode(detail.url)
                        // Pass lastPageIndex if resuming same chapter
                        val history = detailViewModel.lastReadChapter.value
                        val initialPage = if (history?.lastReadChapterUrl == chapterItem.url) {
                            history.lastPageIndex
                        } else 0
                        navController.navigate("reader?mangaTitle=$encTitle&mangaCoverUrl=$encCover&chapterUrl=$encChapterUrl&mangaUrl=$encMangaUrl&initialPage=$initialPage")
                    }
                }
            )
        }

        // 3. Reader Screen Route with a sequential chapter list feed
        composable(
            route = "reader?mangaTitle={mangaTitle}&mangaCoverUrl={mangaCoverUrl}&chapterUrl={chapterUrl}&mangaUrl={mangaUrl}&initialPage={initialPage}",
            arguments = listOf(
                navArgument("mangaTitle") { type = NavType.StringType },
                navArgument("mangaCoverUrl") { type = NavType.StringType },
                navArgument("chapterUrl") { type = NavType.StringType },
                navArgument("mangaUrl") { type = NavType.StringType; defaultValue = "" },
                navArgument("initialPage") { type = NavType.IntType; defaultValue = 0 }
            )
        ) { backStackEntry ->
            val mangaTitle = Uri.decode(backStackEntry.arguments?.getString("mangaTitle") ?: "")
            val mangaCoverUrl = Uri.decode(backStackEntry.arguments?.getString("mangaCoverUrl") ?: "")
            val chapterUrl = Uri.decode(backStackEntry.arguments?.getString("chapterUrl") ?: "")
            val mangaUrl = Uri.decode(backStackEntry.arguments?.getString("mangaUrl") ?: "")
            val initialPage = backStackEntry.arguments?.getInt("initialPage") ?: 0

            val factory = MangaViewModelFactory(repository)
            val readerViewModel: ReaderViewModel = androidx.lifecycle.viewmodel.compose.viewModel(factory = factory)

            val previousBackStackEntry = navController.previousBackStackEntry
            val parentDetailViewModel = previousBackStackEntry?.let {
                val parentFactory = MangaViewModelFactory(repository)
                androidx.lifecycle.viewmodel.compose.viewModel<DetailViewModel>(it, factory = parentFactory)
            }

            val parentChapters = parentDetailViewModel?.mangaDetail?.value?.chapters ?: emptyList()

            ReaderScreen(
                viewModel = readerViewModel,
                mangaTitle = mangaTitle,
                mangaCoverUrl = mangaCoverUrl,
                chapterUrl = chapterUrl,
                mangaUrl = mangaUrl,
                allChapters = parentChapters,
                initialPageIndex = initialPage,
                onBackClick = { navController.popBackStack() }
            )
        }
    }
}
