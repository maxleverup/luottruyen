package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

// Elegant Dark Palette
val ElegantDarkBg = Color(0xFF111318)
val ElegantDarkSurface = Color(0xFF1C1B1F)
val ElegantDarkSurfaceVariant = Color(0xFF2B2930)
val ElegantDarkPrimary = Color(0xFFD0BCFF)
val ElegantDarkOnPrimary = Color(0xFF381E72)
val ElegantDarkSecondary = Color(0xFFE8DEF8)
val ElegantDarkOnSecondary = Color(0xFF1D1B20)
val ElegantDarkSecondaryContainer = Color(0xFF4F378B)
val ElegantDarkOnSecondaryContainer = Color(0xFFEADDFF)
val ElegantDarkText = Color(0xFFE2E2E6)
val ElegantDarkTextSecondary = Color(0xFFC4C6CF)
val ElegantDarkTextMuted = Color(0xFF909094)
val ElegantDarkBorder = Color(0xFF44474E)


