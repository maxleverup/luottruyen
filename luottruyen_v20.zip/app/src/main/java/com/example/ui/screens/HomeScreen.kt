package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.border
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.data.model.FavoriteManga
import com.example.data.model.MangaItem
import com.example.data.model.ReadingHistory
import com.example.ui.viewmodel.HomeViewModel
import com.example.data.AppSettings
import com.example.data.scraper.MangaScraper
import android.webkit.CookieManager
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.SslErrorHandler
import android.net.http.SslError
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.launch
import android.content.Intent
import android.net.Uri

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: HomeViewModel,
    onNavigateToDetail: (String) -> Unit,
    onNavigateToReader: (String, String, String, String) -> Unit,
    openSettingsOnLaunch: Boolean = false,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var selectedTab by remember { mutableStateOf(0) }
    var isFilterDialogVisible by remember { mutableStateOf(false) }
    var isSearchActive by remember { mutableStateOf(false) }
    var rawSearchText by remember { mutableStateOf("") }

    var showSettingsDialog by remember { mutableStateOf(false) }
    var showCookieDialog by remember { mutableStateOf(false) }
    var currentWebUrl by remember { mutableStateOf(com.example.data.AppSettings.baseUrl) }
    var loggedInUserByApp by remember { mutableStateOf(com.example.data.AppSettings.loggedInUserName) }
    var manualCookieText by remember { mutableStateOf("") }
    var cookieTestingStatus by remember { mutableStateOf("") }

    // Auto-open settings when triggered from outside (e.g. login required)
    var loginRequiredBanner by remember { mutableStateOf(false) }
    LaunchedEffect(openSettingsOnLaunch) {
        if (openSettingsOnLaunch) {
            loginRequiredBanner = true
            showSettingsDialog = true
        }
    }
    
    LaunchedEffect(showSettingsDialog, showCookieDialog) {
        if (showSettingsDialog || showCookieDialog) {
            manualCookieText = com.example.data.AppSettings.cookies
            cookieTestingStatus = ""
        }
    }
    
    val coroutineScope = rememberCoroutineScope()
    
    LaunchedEffect(Unit) {
        val checkedName = com.example.data.scraper.MangaScraper.checkLoginStatus()
        com.example.data.AppSettings.loggedInUserName = checkedName
        loggedInUserByApp = checkedName
    }

    val latestMangas by viewModel.latestMangas.collectAsStateWithLifecycle()
    val searchResults by viewModel.searchResults.collectAsStateWithLifecycle()
    val genres by viewModel.genres.collectAsStateWithLifecycle()
    val selectedGenre by viewModel.selectedGenre.collectAsStateWithLifecycle()
    val isLoading by viewModel.isLoading.collectAsStateWithLifecycle()
    val isLoadingMore by viewModel.isLoadingMore.collectAsStateWithLifecycle()
    val hasMorePages by viewModel.hasMorePages.collectAsStateWithLifecycle()
    val favorites by viewModel.favorites.collectAsStateWithLifecycle()
    val historyList by viewModel.readingHistory.collectAsStateWithLifecycle()
    val filterMinRating by viewModel.filterMinRating.collectAsStateWithLifecycle()
    val filterMinChap by viewModel.filterMinChap.collectAsStateWithLifecycle()
    val filterGenres by viewModel.filterGenres.collectAsStateWithLifecycle()

    // Danh sách manga sau khi áp bộ lọc client-side
    val filteredMangas = remember(latestMangas, filterMinRating, filterMinChap, filterGenres) {
        viewModel.applyFilters(latestMangas)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    if (isSearchActive) {
                        TextField(
                            value = rawSearchText,
                            onValueChange = {
                                rawSearchText = it
                                viewModel.search(it)
                            },
                            placeholder = { Text("Tìm kiếm truyện tranh...", color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)) },
                            singleLine = true,
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color.Transparent,
                                unfocusedContainerColor = Color.Transparent,
                                disabledContainerColor = Color.Transparent,
                                focusedIndicatorColor = Color.Transparent,
                                unfocusedIndicatorColor = Color.Transparent
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("search_input_fields"),
                            textStyle = LocalTextStyle.current.copy(fontSize = 18.sp, color = MaterialTheme.colorScheme.onSurface)
                        )
                    } else {
                        Column {
                            Text(
                                "Lướt Truyện",
                                fontWeight = FontWeight.Black,
                                fontSize = 22.sp,
                                letterSpacing = 0.5.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                "Developer: Nguyen Quoc An",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                actions = {
                    if (isSearchActive) {
                        IconButton(
                            onClick = {
                                isSearchActive = false
                                rawSearchText = ""
                                viewModel.search("")
                            },
                            modifier = Modifier.testTag("close_search_btn")
                        ) {
                            Icon(Icons.Default.Close, contentDescription = "Đóng Tìm Kiếm")
                        }
                    } else {
                        IconButton(
                            onClick = { showSettingsDialog = true },
                            modifier = Modifier.testTag("settings_action_btn")
                        ) {
                            Icon(Icons.Default.Settings, contentDescription = "Cài đặt")
                        }
                        IconButton(
                            onClick = { isSearchActive = true },
                            modifier = Modifier.testTag("search_action_btn")
                        ) {
                            Icon(Icons.Default.Search, contentDescription = "Tìm kiếm")
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp,
                windowInsets = WindowInsets.navigationBars
            ) {
                NavigationBarItem(
                    selected = selectedTab == 0 && !isSearchActive,
                    onClick = {
                        selectedTab = 0
                        isSearchActive = false
                    },
                    icon = { Icon(Icons.Default.Explore, contentDescription = "Khám phá") },
                    label = { Text("Mới cập nhật") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = MaterialTheme.colorScheme.primary,
                        selectedTextColor = MaterialTheme.colorScheme.primary
                    )
                )
                NavigationBarItem(
                    selected = selectedTab == 1 && !isSearchActive,
                    onClick = {
                        selectedTab = 1
                        isSearchActive = false
                    },
                    icon = { Icon(Icons.Default.Favorite, contentDescription = "Yêu thích") },
                    label = { Text("Yêu thích") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = MaterialTheme.colorScheme.primary,
                        selectedTextColor = MaterialTheme.colorScheme.primary
                    )
                )
                NavigationBarItem(
                    selected = selectedTab == 2 && !isSearchActive,
                    onClick = {
                        selectedTab = 2
                        isSearchActive = false
                    },
                    icon = { Icon(Icons.Default.History, contentDescription = "Lịch sử") },
                    label = { Text("Lịch sử") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = MaterialTheme.colorScheme.primary,
                        selectedTextColor = MaterialTheme.colorScheme.primary
                    )
                )
            }
        },
        modifier = modifier
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(MaterialTheme.colorScheme.background)
        ) {
            if (isSearchActive && rawSearchText.isNotBlank()) {
                // Search Results View
                if (isLoading && searchResults.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                    }
                } else if (searchResults.isEmpty()) {
                    EmptyStateView(
                        icon = Icons.Default.SearchOff,
                        title = "Không tìm thấy truyện",
                        subtitle = "Hãy thử nhập từ khóa khác xem nhé!"
                    )
                } else {
                    MangaGrid(
                        mangaList = searchResults,
                        onItemClick = { onNavigateToDetail(it.url) },
                        onLoadMore = {} // No search pagination for simplicity
                    )
                }
            } else {
                when (selectedTab) {
                    0 -> {
                        // Discover Tab with Category selection & Infinite scroll
                        Column(modifier = Modifier.fillMaxSize()) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 16.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = { isFilterDialogVisible = true },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = MaterialTheme.colorScheme.secondaryContainer,
                                        contentColor = MaterialTheme.colorScheme.onSecondaryContainer
                                    ),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.testTag("genre_menu_btn"),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Menu,
                                        contentDescription = "Bộ lọc",
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Bộ lọc", fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                                    // Hiển thị badge nếu có bộ lọc đang áp dụng
                                    val hasActiveFilter = filterMinRating > 0f || filterMinChap > 0 || filterGenres.isNotEmpty() || selectedGenre != null
                                    if (hasActiveFilter) {
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Box(
                                            modifier = Modifier
                                                .size(8.dp)
                                                .clip(RoundedCornerShape(4.dp))
                                                .background(MaterialTheme.colorScheme.primary)
                                        )
                                    }
                                }
                                
                                if (selectedGenre != null) {
                                    InputChip(
                                        selected = true,
                                        onClick = { viewModel.selectGenre(null) },
                                        label = { Text(selectedGenre!!.first) },
                                        trailingIcon = {
                                            Icon(
                                                imageVector = Icons.Default.Close,
                                                contentDescription = "Bỏ lọc",
                                                modifier = Modifier.size(16.dp)
                                            )
                                        },
                                        colors = InputChipDefaults.inputChipColors(
                                            selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                            selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer,
                                            selectedTrailingIconColor = MaterialTheme.colorScheme.onPrimaryContainer
                                        )
                                    )
                                } else {
                                    AssistChip(
                                        onClick = {},
                                        label = { Text("Tất cả truyện") },
                                        colors = AssistChipDefaults.assistChipColors(
                                            labelColor = MaterialTheme.colorScheme.primary,
                                            containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f)
                                        ),
                                        border = null
                                    )
                                }
                            }
                            
                            if (isLoading && latestMangas.isEmpty()) {
                                Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                                    CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                                }
                            } else if (latestMangas.isEmpty()) {
                                Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                                    EmptyStateView(
                                        icon = Icons.Default.CloudOff,
                                        title = "Kết nối không ổn định",
                                        subtitle = "Không thể tải danh sách truyện. Hãy thử lại sau nha."
                                    )
                                }
                            } else if (filteredMangas.isEmpty()) {
                                Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                                    EmptyStateView(
                                        icon = Icons.Default.FilterList,
                                        title = "Không có truyện phù hợp",
                                        subtitle = "Thử điều chỉnh lại bộ lọc để xem thêm truyện nha."
                                    )
                                }
                            } else {
                                Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                                    MangaGrid(
                                        mangaList = filteredMangas,
                                        onItemClick = { onNavigateToDetail(it.url) },
                                        onLoadMore = { viewModel.loadMore() },
                                        isLoadingMore = isLoadingMore,
                                        hasMorePages = hasMorePages
                                    )
                                }
                            }
                        }
                    }
                    1 -> {
                        // Favorites Tab
                        if (favorites.isEmpty()) {
                            EmptyStateView(
                                icon = Icons.Default.BookmarkBorder,
                                title = "Chưa có truyện yêu thích",
                                subtitle = "Nhấn nút Tim trong mô tả truyện để lưu lại tại đây nha!"
                            )
                        } else {
                            val downloadedSlugsSet = remember(favorites) {
                                favorites.filter { it.isDownloaded }.map { it.slug }.toSet()
                            }
                            val favAsMangaItems = favorites.map {
                                MangaItem(url = it.url, title = it.title, coverUrl = it.coverUrl)
                            }
                            MangaGrid(
                                mangaList = favAsMangaItems,
                                onItemClick = { onNavigateToDetail(it.url) },
                                onLoadMore = {},
                                downloadedSlugs = downloadedSlugsSet
                            )
                        }
                    }
                    2 -> {
                        // History Tab
                        if (historyList.isEmpty()) {
                            EmptyStateView(
                                icon = Icons.Default.HistoryToggleOff,
                                title = "Lịch sử trống trơn",
                                subtitle = "Các chapters bạn đọc sẽ được ghi nhớ tự động ở đây."
                            )
                        } else {
                            Column(modifier = Modifier.fillMaxSize()) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 16.dp, vertical = 8.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        "Lịch sử đọc gần đây",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp,
                                        color = MaterialTheme.colorScheme.onBackground
                                    )
                                    TextButton(
                                        onClick = { viewModel.clearAllHistory() },
                                        colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)
                                    ) {
                                        Icon(Icons.Default.DeleteSweep, contentDescription = "Xóa toàn bộ", modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Xóa hết", fontSize = 13.sp)
                                    }
                                }
                                
                                LazyColumn(
                                    modifier = Modifier.fillMaxSize(),
                                    contentPadding = PaddingValues(bottom = 24.dp)
                                ) {
                                    items(historyList, key = { it.slug }) { history ->
                                        HistoryRowItem(
                                            history = history,
                                            onItemClick = { 
                                                val detailSlug = if (history.mangaUrl.isNotEmpty()) history.mangaUrl else history.slug
                                                onNavigateToDetail(detailSlug) 
                                            },
                                            onContinueReading = {
                                                onNavigateToReader(
                                                    history.title,
                                                    history.coverUrl,
                                                    history.lastReadChapterUrl,
                                                    history.mangaUrl
                                                )
                                            },
                                            onDeleteClick = { viewModel.deleteHistoryItem(history.slug) }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showSettingsDialog) {
        AlertDialog(
            onDismissRequest = {
                showSettingsDialog = false
                loginRequiredBanner = false
            },
            title = {
                Text(
                    text = "Thiết lập nguồn truyện",
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp,
                    color = MaterialTheme.colorScheme.primary
                )
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Login required banner
                    if (loginRequiredBanner) {
                        androidx.compose.material3.Surface(
                            modifier = Modifier.fillMaxWidth(),
                            color = MaterialTheme.colorScheme.errorContainer,
                            shape = androidx.compose.foundation.shape.RoundedCornerShape(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    Icons.Default.Lock,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.error,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Bạn cần đăng nhập để đọc truyện. Vui lòng nhập cookie đăng nhập bên dưới.",
                                    fontSize = 13.sp,
                                    color = MaterialTheme.colorScheme.onErrorContainer,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }

                    // 1. Web URL setting
                    OutlinedTextField(
                        value = currentWebUrl,
                        onValueChange = { currentWebUrl = it },
                        label = { Text("Địa chỉ trang web hiện tại") },
                        placeholder = { Text("https://luottruyen6.com") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MaterialTheme.colorScheme.primary,
                            unfocusedBorderColor = MaterialTheme.colorScheme.outline
                        )
                    )
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextButton(
                            onClick = {
                                currentWebUrl = "https://luottruyen6.com"
                            }
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Khôi phục mặc định", fontSize = 12.sp)
                        }
                    }
                    
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                    
                    // 2. Login Status setting
                    Text(
                        text = "Trạng thái đăng nhập",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(
                                if (loggedInUserByApp.isNotEmpty())
                                    MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.2f)
                                else
                                    MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.1f)
                            )
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (loggedInUserByApp.isNotEmpty()) Icons.Default.CheckCircle else Icons.Default.Cancel,
                            contentDescription = null,
                            tint = if (loggedInUserByApp.isNotEmpty()) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (loggedInUserByApp.isNotEmpty()) "Tài khoản: $loggedInUserByApp" else "Chưa đăng nhập",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = if (loggedInUserByApp.isNotEmpty()) "Đã sẵn sàng tải chapters từ web!" else "Bắt buộc đăng nhập để đọc được truyện.",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        
                        Spacer(modifier = Modifier.width(8.dp))
                        
                        if (loggedInUserByApp.isNotEmpty()) {
                            Button(
                                onClick = {
                                    CookieManager.getInstance().removeAllCookies(null)
                                    com.example.data.AppSettings.cookies = ""
                                    com.example.data.AppSettings.loggedInUserName = ""
                                    loggedInUserByApp = ""
                                    manualCookieText = ""
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD32F2F)),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                modifier = Modifier.height(36.dp)
                            ) {
                                Text("Đăng xuất", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            }
                        } else {
                            Button(
                                onClick = {
                                    showCookieDialog = true
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                modifier = Modifier.height(36.dp)
                            ) {
                                Text("Đăng nhập", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            }
                        }
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                    // 3. Export / Import data
                    Text(
                        text = "Sao lưu & Khôi phục dữ liệu",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "Bao gồm: cookie đăng nhập, truyện yêu thích, lịch sử đọc.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    val backupScope = rememberCoroutineScope()
                    var backupStatus by remember { mutableStateOf("") }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Export button
                        OutlinedButton(
                            onClick = {
                                backupScope.launch {
                                    val result = com.example.data.util.DataBackupManager.exportData(context)
                                    backupStatus = result.fold(
                                        onSuccess = { "✓ Đã xuất: ${it.absolutePath}" },
                                        onFailure = { "✗ Lỗi: ${it.message}" }
                                    )
                                }
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.Upload, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Xuất file", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }

                        // Import button
                        Button(
                            onClick = {
                                backupScope.launch {
                                    val file = com.example.data.util.DataBackupManager.getBackupFile()
                                    if (file.exists()) {
                                        val result = com.example.data.util.DataBackupManager.importData(context, file)
                                        backupStatus = result.fold(
                                            onSuccess = { "✓ Đã nhập:\n$it" },
                                            onFailure = { "✗ Lỗi: ${it.message}" }
                                        )
                                        // Refresh login state
                                        loggedInUserByApp = com.example.data.AppSettings.loggedInUserName
                                    } else {
                                        backupStatus = "✗ Không tìm thấy file backup tại\nDownload/Luottruyen/"
                                    }
                                }
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                        ) {
                            Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Nhập file", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    if (backupStatus.isNotEmpty()) {
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            color = if (backupStatus.startsWith("✓"))
                                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f)
                            else
                                MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.3f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = backupStatus,
                                modifier = Modifier.padding(10.dp),
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val oldUrl = com.example.data.AppSettings.baseUrl
                        val cleanUrl = if (currentWebUrl.endsWith("/")) currentWebUrl.removeSuffix("/") else currentWebUrl
                        com.example.data.AppSettings.baseUrl = cleanUrl
                        showSettingsDialog = false
                        
                        if (oldUrl != cleanUrl) {
                            viewModel.loadGenres()
                            viewModel.loadLatest(1, append = false)
                        }
                    }
                ) {
                    Text("Lưu & Đóng")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        showSettingsDialog = false
                        currentWebUrl = com.example.data.AppSettings.baseUrl
                    }
                ) {
                    Text("Hủy")
                }
            }
        )
    }

    if (showCookieDialog) {
        AlertDialog(
            onDismissRequest = { showCookieDialog = false },
            title = {
                Text(
                    text = "Nhập Cookie đăng nhập",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = MaterialTheme.colorScheme.primary
                )
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedTextField(
                        value = manualCookieText,
                        onValueChange = { manualCookieText = it },
                        label = { Text("Mã Cookie (String)") },
                        placeholder = { Text("ASP.NET_SessionId=...; .ASPXAUTH=...") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 3,
                        maxLines = 5,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MaterialTheme.colorScheme.primary,
                            unfocusedBorderColor = MaterialTheme.colorScheme.outline
                        )
                    )
                    
                    if (cookieTestingStatus.isNotEmpty()) {
                        Text(
                            text = cookieTestingStatus,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = if (cookieTestingStatus.contains("thành công")) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                        )
                    }
                    
                    Button(
                        onClick = {
                            cookieTestingStatus = "Đang kiểm tra cookie..."
                            com.example.data.AppSettings.cookies = manualCookieText
                            coroutineScope.launch {
                                val detectedName = com.example.data.scraper.MangaScraper.checkLoginStatus()
                                if (detectedName.isNotEmpty()) {
                                    com.example.data.AppSettings.loggedInUserName = detectedName
                                    loggedInUserByApp = detectedName
                                    cookieTestingStatus = "Đăng nhập thành công: $detectedName"
                                    viewModel.loadLatest(1, append = false)
                                    kotlinx.coroutines.delay(800)
                                    showCookieDialog = false
                                } else {
                                    cookieTestingStatus = "Lỗi: Cookie không hợp lệ hoặc hết hạn!"
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32))
                    ) {
                        Text("Áp dụng Cookie", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showCookieDialog = false }) {
                    Text("Đóng")
                }
            }
        )
    }

    if (isFilterDialogVisible) {
        FilterDialog(
            genres = genres,
            selectedGenre = selectedGenre,
            initialMinRating = filterMinRating,
            initialMinChap = filterMinChap,
            initialSelectedGenres = filterGenres,
            onDismiss = { isFilterDialogVisible = false },
            onApply = { minRating, minChap, selectedGenresSet, newGenre ->
                viewModel.saveFilters(minRating, minChap, selectedGenresSet)
                if (newGenre != selectedGenre) {
                    viewModel.selectGenre(newGenre)
                }
                isFilterDialogVisible = false
            },
            onReset = {
                viewModel.resetFilters()
                viewModel.selectGenre(null)
                isFilterDialogVisible = false
            }
        )
    }
}

@Composable
fun GenreGridItem(
    name: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(12.dp),
        color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
        contentColor = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier
            .fillMaxWidth()
            .height(46.dp)
    ) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = name,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FilterDialog(
    genres: List<Pair<String, String>>,
    selectedGenre: Pair<String, String>?,
    initialMinRating: Float,
    initialMinChap: Int,
    initialSelectedGenres: Set<String>,
    onDismiss: () -> Unit,
    onApply: (minRating: Float, minChap: Int, selectedGenres: Set<String>, genre: Pair<String, String>?) -> Unit,
    onReset: () -> Unit
) {
    // Local state bên trong dialog — chỉ lưu khi bấm "Lưu thiết lập"
    var localRating by remember { mutableStateOf(initialMinRating) }
    var localChap by remember { mutableStateOf(initialMinChap.toFloat()) }
    var localGenres by remember { mutableStateOf(initialSelectedGenres.toMutableSet()) }
    var localSelectedGenre by remember { mutableStateOf(selectedGenre) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.88f)
                .clip(RoundedCornerShape(24.dp)),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Header
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Bộ lọc",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black,
                        color = MaterialTheme.colorScheme.primary
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Đóng")
                    }
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                // Scrollable content
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 20.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(20.dp)
                ) {
                    // === Phần 1: Lọc theo đánh giá ===
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Star,
                                    contentDescription = null,
                                    tint = Color(0xFFFFC107),
                                    modifier = Modifier.size(18.dp)
                                )
                                Text(
                                    text = "Đánh giá tối thiểu",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                            Text(
                                text = if (localRating <= 0f) "Tất cả" else "≥ ${"%.1f".format(localRating)} ★",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        // Thanh trượt rating: 0 → 5, bước 0.2
                        Slider(
                            value = localRating,
                            onValueChange = { localRating = (it * 5).toInt() / 5f * 1f
                                // Snap to 0.2 steps
                                localRating = (Math.round(it / 0.2f) * 0.2f).coerceIn(0f, 5f)
                            },
                            valueRange = 0f..5f,
                            steps = 24, // 25 positions = 0, 0.2, 0.4,... 5.0 → 24 steps between
                            modifier = Modifier.fillMaxWidth(),
                            colors = SliderDefaults.colors(
                                thumbColor = MaterialTheme.colorScheme.primary,
                                activeTrackColor = MaterialTheme.colorScheme.primary,
                                inactiveTrackColor = MaterialTheme.colorScheme.primaryContainer
                            )
                        )
                        // Nhãn bậc lớn
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            for (v in 0..5) {
                                Text(
                                    text = "$v",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                                )
                            }
                        }
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

                    // === Phần 2: Lọc theo số chap ===
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.MenuBook,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.secondary,
                                    modifier = Modifier.size(18.dp)
                                )
                                Text(
                                    text = "Số chap tối thiểu",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                            Text(
                                text = if (localChap <= 0f) "Tất cả" else "≥ ${localChap.toInt()} chap",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.secondary
                            )
                        }
                        // Thanh trượt chap: 0 → 100, bước 10 (bậc lớn) và bước nhỏ không cần snap cứng
                        Slider(
                            value = localChap,
                            onValueChange = { raw ->
                                // Snap to nearest 10
                                localChap = (Math.round(raw / 10f) * 10f).coerceIn(0f, 100f)
                            },
                            valueRange = 0f..100f,
                            steps = 9, // 10 segments → 9 steps between (0,10,20,...100)
                            modifier = Modifier.fillMaxWidth(),
                            colors = SliderDefaults.colors(
                                thumbColor = MaterialTheme.colorScheme.secondary,
                                activeTrackColor = MaterialTheme.colorScheme.secondary,
                                inactiveTrackColor = MaterialTheme.colorScheme.secondaryContainer
                            )
                        )
                        // Nhãn bậc lớn
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            for (v in listOf(0, 20, 40, 60, 80, 100)) {
                                Text(
                                    text = "$v",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                                )
                            }
                        }
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

                    // === Phần 3: Lọc theo thể loại ===
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Category,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.tertiary,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = "Thể loại",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            if (localSelectedGenre != null || localGenres.isNotEmpty()) {
                                Spacer(modifier = Modifier.width(4.dp))
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = MaterialTheme.colorScheme.tertiaryContainer
                                ) {
                                    Text(
                                        text = if (localSelectedGenre != null) "1 đã chọn" else "${localGenres.size} đã chọn",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.onTertiaryContainer,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }

                        // "Tất cả" chip
                        LazyVerticalGrid(
                            columns = GridCells.Fixed(3),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.heightIn(max = 400.dp)
                        ) {
                            item {
                                val isAllSelected = localSelectedGenre == null && localGenres.isEmpty()
                                FilterGenreChip(
                                    name = "Tất cả",
                                    isSelected = isAllSelected,
                                    onClick = {
                                        localSelectedGenre = null
                                        localGenres = mutableSetOf()
                                    }
                                )
                            }
                            items(genres) { genre ->
                                val isSelected = localSelectedGenre?.first == genre.first
                                FilterGenreChip(
                                    name = genre.first,
                                    isSelected = isSelected,
                                    onClick = {
                                        localSelectedGenre = if (isSelected) null else genre
                                        localGenres = mutableSetOf()
                                    }
                                )
                            }
                        }
                    }
                }

                // Bottom buttons
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            localRating = 0f
                            localChap = 0f
                            localGenres = mutableSetOf()
                            localSelectedGenre = null
                            onReset()
                        },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Đặt lại")
                    }
                    Button(
                        onClick = {
                            onApply(localRating, localChap.toInt(), localGenres, localSelectedGenre)
                        },
                        modifier = Modifier.weight(2f),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Lưu thiết lập", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun FilterGenreChip(
    name: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(10.dp),
        color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
        contentColor = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
        border = if (isSelected) null else androidx.compose.foundation.BorderStroke(
            0.5.dp,
            MaterialTheme.colorScheme.outlineVariant
        ),
        modifier = Modifier
            .fillMaxWidth()
            .height(40.dp)
    ) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = name,
                fontSize = 12.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(horizontal = 4.dp)
            )
        }
    }
}

@Composable
fun MangaGrid(
    mangaList: List<MangaItem>,
    onItemClick: (MangaItem) -> Unit,
    onLoadMore: () -> Unit,
    downloadedSlugs: Set<String> = emptySet(),
    isLoadingMore: Boolean = false,
    hasMorePages: Boolean = true
) {
    val gridState = rememberLazyGridState()
    
    // Trigger loadMore khi còn 12 item cuối — đủ sớm để tải trước khi user chạm đáy
    val shouldLoadMore = remember {
        derivedStateOf {
            if (!hasMorePages || isLoadingMore) return@derivedStateOf false
            val totalItems = gridState.layoutInfo.totalItemsCount
            val lastVisibleItem = gridState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
            totalItems > 0 && lastVisibleItem >= totalItems - 12
        }
    }

    LaunchedEffect(shouldLoadMore.value) {
        if (shouldLoadMore.value) {
            onLoadMore()
        }
    }

    LazyVerticalGrid(
        columns = GridCells.Fixed(3),
        state = gridState,
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        items(mangaList, key = { it.url }) { manga ->
            MangaGridItem(
                manga = manga,
                onClick = { onItemClick(manga) },
                isDownloaded = manga.slug in downloadedSlugs
            )
        }
        // Footer: spinner khi đang load thêm, hoặc dấu chấm hết khi hết trang
        item(span = { GridItemSpan(maxLineSpan) }) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 16.dp),
                contentAlignment = Alignment.Center
            ) {
                when {
                    isLoadingMore -> {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                strokeWidth = 2.dp,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                "Đang tải thêm truyện...",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    !hasMorePages && mangaList.isNotEmpty() -> {
                        Text(
                            "— Đã hiển thị tất cả truyện —",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                        )
                    }
                    else -> {
                        Spacer(modifier = Modifier.height(16.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun MangaGridItem(
    manga: MangaItem,
    onClick: () -> Unit,
    isDownloaded: Boolean = false
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("manga_item_${manga.slug.replace("-", "_")}"),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        elevation = CardDefaults.cardElevation(0.dp)
    ) {
        Column {
            Box(
                modifier = Modifier
                    .aspectRatio(0.7f)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
            ) {
                // Image with secure referer
                val context = LocalContext.current
                val request = remember(manga.coverUrl) {
                    ImageRequest.Builder(context)
                        .data(manga.coverUrl.ifEmpty { "https://luottruyen6.com/favicon.ico" })
                        .addHeader("Referer", "https://luottruyen6.com/")
                        .crossfade(true)
                        .placeholder(android.R.drawable.ic_menu_gallery)
                        .error(android.R.drawable.ic_menu_gallery)
                        .build()
                }

                AsyncImage(
                    model = request,
                    contentDescription = manga.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )

                // TOP-RIGHT: Downloaded tag
                if (isDownloaded) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(5.dp)
                            .background(
                                color = Color(0xFF1E88E5).copy(alpha = 0.93f),
                                shape = RoundedCornerShape(5.dp)
                            )
                            .padding(horizontal = 4.dp, vertical = 2.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.OfflinePin,
                                contentDescription = "Đã tải",
                                tint = Color.White,
                                modifier = Modifier.size(9.dp)
                            )
                            Spacer(modifier = Modifier.width(2.dp))
                            Text(
                                text = "Offline",
                                fontSize = 7.5.sp,
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                // TOP-LEFT: Chapter bookmark — 2 lines: "Ch." on top, number below
                val hasChapterFlagInner = manga.latestChapter.isNotBlank()
                if (hasChapterFlagInner) {
                    val chapterNumOnly = run {
                        val raw = manga.latestChapter
                        Regex("\\d+(\\.\\d+)?").find(raw)?.value ?: raw.take(6)
                    }
                    Column(
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(start = 7.dp)
                            .background(
                                color = Color.Black.copy(alpha = 0.60f),
                                shape = RoundedCornerShape(bottomStart = 8.dp, bottomEnd = 8.dp)
                            )
                            .border(
                                width = 1.5.dp,
                                color = Color(0xFF1565C0),
                                shape = RoundedCornerShape(bottomStart = 8.dp, bottomEnd = 8.dp)
                            )
                            .padding(horizontal = 9.dp, vertical = 6.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "Ch.",
                            fontSize = 10.sp,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            lineHeight = 11.sp
                        )
                        Text(
                            text = chapterNumOnly,
                            fontSize = 12.sp,
                            color = Color.White,
                            fontWeight = FontWeight.ExtraBold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            lineHeight = 13.sp
                        )
                    }
                }

                // Bottom overlay: Rating / Views — more transparent, slimmer
                val hasRating = manga.rating.isNotBlank() && manga.rating != "0.0" && manga.rating != "0"
                val hasViews = manga.views.isNotBlank()

                if (hasRating || hasViews) {
                    Row(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .fillMaxWidth()
                            .background(Color.Black.copy(alpha = 0.60f))
                            .padding(horizontal = 5.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        if (hasRating) {
                            Icon(
                                imageVector = Icons.Default.Star,
                                contentDescription = "Rating",
                                tint = Color(0xFFFFC107),
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(2.dp))
                            Text(manga.rating, fontSize = 12.sp, color = Color.White, fontWeight = FontWeight.Bold)
                        }
                        if (hasViews) {
                            if (hasRating) Spacer(modifier = Modifier.width(6.dp))
                            Icon(
                                imageVector = Icons.Default.RemoveRedEye,
                                contentDescription = "Views",
                                tint = Color.White,
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(2.dp))
                            Text(manga.views, fontSize = 12.sp, color = Color.White, fontWeight = FontWeight.Bold,
                                maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            } // end Box



            Spacer(modifier = Modifier.height(6.dp))
            
            Text(
                text = manga.title,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 2,
                minLines = 2,
                lineHeight = 16.sp,
                overflow = TextOverflow.Ellipsis,
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.padding(horizontal = 2.dp)
            )
        }
    }
}

@Composable
fun HistoryRowItem(
    history: ReadingHistory,
    onItemClick: () -> Unit,
    onContinueReading: () -> Unit,
    onDeleteClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 6.dp)
            .clickable(onClick = onItemClick),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            val context = LocalContext.current
            val request = remember(history.coverUrl) {
                ImageRequest.Builder(context)
                    .data(history.coverUrl)
                    .addHeader("Referer", "https://luottruyen6.com/")
                    .crossfade(true)
                    .build()
            }

            AsyncImage(
                model = request,
                contentDescription = history.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(width = 54.dp, height = 76.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
            )

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    history.title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Default.ChromeReaderMode,
                        contentDescription = "Đọc tiếp",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(13.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        "Đã đọc: " + history.lastReadChapterName,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                Button(
                    onClick = onContinueReading,
                    modifier = Modifier.height(30.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp),
                    shape = RoundedCornerShape(6.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f),
                        contentColor = MaterialTheme.colorScheme.primary
                    )
                ) {
                    Text("Đọc Tiếp", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }

            IconButton(onClick = onDeleteClick) {
                Icon(Icons.Default.DeleteOutline, contentDescription = "Xóa lịch sử", tint = MaterialTheme.colorScheme.error.copy(alpha = 0.7f))
            }
        }
    }
}

@Composable
fun EmptyStateView(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f),
                modifier = Modifier.size(64.dp)
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                title,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                subtitle,
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 16.dp),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                lineHeight = 18.sp
            )
        }
    }
}
