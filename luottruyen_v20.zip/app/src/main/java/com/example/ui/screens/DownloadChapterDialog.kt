package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.ChapterItem

@Composable
fun DownloadChapterDialog(
    chapters: List<ChapterItem>,        // full list, index 0 = newest
    mangaTitle: String,
    downloadedChapterUrls: Set<String>,
    isDownloading: Boolean,
    downloadProgress: Float,
    downloadingChapterName: String,
    onDownloadSelected: (fromIdx: Int, toIdx: Int) -> Unit,  // indices into chapters list
    onDownloadAll: () -> Unit,
    onCancel: () -> Unit,
    onDismiss: () -> Unit
) {
    // chapters sorted: index 0 = newest; we'll display min/max by chapter number
    // minIdx = oldest end (higher index), maxIdx = newest end (lower index)
    // The slider: left = chapter min number (oldest = chapters.lastIndex), right = max (newest = 0)
    // For display: we show chapterNumber = chapters.size - index

    val totalChapters = chapters.size

    // Track drag range [startFrac .. endFrac] in 0..1
    // 0 = leftmost = chapter 1 (oldest), 1 = rightmost = chapter totalChapters (newest)
    var startFrac by remember { mutableStateOf(0f) }
    var endFrac by remember { mutableStateOf(1f) }

    var barWidthPx by remember { mutableStateOf(0f) }

    // Convert fractions to chapter indices
    // frac 0 = oldest = chapters[totalChapters-1], frac 1 = newest = chapters[0]
    val minChapNum = remember(startFrac, totalChapters) {
        (startFrac * (totalChapters - 1)).toInt().coerceIn(0, totalChapters - 1) + 1
    }
    val maxChapNum = remember(endFrac, totalChapters) {
        (endFrac * (totalChapters - 1)).toInt().coerceIn(0, totalChapters - 1) + 1
    }

    // Convert chapter number to chapters list index (0=newest, lastIndex=oldest)
    fun chapNumToListIndex(chapNum: Int): Int = (totalChapters - chapNum).coerceIn(0, totalChapters - 1)

    Dialog(
        onDismissRequest = { if (!isDownloading) onDismiss() },
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .wrapContentHeight(),
            shape = RoundedCornerShape(20.dp),
            color = Color(0xFF1C1C2E),
            tonalElevation = 8.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Default.Download,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        "Tải xuống chương",
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.weight(1f))
                    if (!isDownloading) {
                        IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                            Icon(Icons.Default.Close, contentDescription = "Đóng", tint = Color.Gray, modifier = Modifier.size(18.dp))
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                if (isDownloading) {
                    // ===== DOWNLOAD IN PROGRESS =====
                    Text(
                        "Đang tải: $downloadingChapterName",
                        fontSize = 13.sp,
                        color = Color.LightGray,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    LinearProgressIndicator(
                        progress = { downloadProgress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = MaterialTheme.colorScheme.primary,
                        trackColor = Color.White.copy(alpha = 0.15f)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        "${(downloadProgress * 100).toInt()}%",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    OutlinedButton(
                        onClick = onCancel,
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.error)
                    ) {
                        Icon(Icons.Default.Cancel, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Hủy và xóa đã tải")
                    }
                } else {
                    // ===== CHAPTER RANGE PICKER =====
                    Text(
                        "Kéo thanh để chọn phạm vi chương cần tải",
                        fontSize = 11.sp,
                        color = Color.Gray,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(14.dp))

                    // Chapter range scrubber
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color.White.copy(alpha = 0.07f))
                            .border(1.dp, Color.White.copy(alpha = 0.1f), RoundedCornerShape(10.dp))
                            .onGloballyPositioned { coords -> barWidthPx = coords.size.width.toFloat() }
                            .pointerInput(totalChapters, barWidthPx) {
                                detectHorizontalDragGestures(
                                    onDragStart = { offset ->
                                        if (barWidthPx <= 0) return@detectHorizontalDragGestures
                                        val frac = (offset.x / barWidthPx).coerceIn(0f, 1f)
                                        // Determine which handle to drag based on proximity
                                        val distToStart = Math.abs(frac - startFrac)
                                        val distToEnd = Math.abs(frac - endFrac)
                                        if (distToStart < distToEnd) {
                                            startFrac = frac.coerceAtMost(endFrac)
                                        } else {
                                            endFrac = frac.coerceAtLeast(startFrac)
                                        }
                                    },
                                    onHorizontalDrag = { change, dragAmount ->
                                        if (barWidthPx <= 0) return@detectHorizontalDragGestures
                                        val delta = dragAmount / barWidthPx
                                        val frac = ((change.position.x) / barWidthPx).coerceIn(0f, 1f)
                                        val distToStart = Math.abs(frac - startFrac)
                                        val distToEnd = Math.abs(frac - endFrac)
                                        if (distToStart <= distToEnd) {
                                            startFrac = (startFrac + delta).coerceIn(0f, endFrac)
                                        } else {
                                            endFrac = (endFrac + delta).coerceIn(startFrac, 1f)
                                        }
                                    }
                                )
                            }
                    ) {
                        // Render tick marks per chapter
                        Row(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(horizontal = 3.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.spacedBy(1.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            for (i in 0 until totalChapters) {
                                val frac = i.toFloat() / (totalChapters - 1).coerceAtLeast(1)
                                val inRange = frac in startFrac..endFrac
                                // Convert to chapters list index to check if downloaded
                                val listIdx = (totalChapters - 1 - i).coerceIn(0, totalChapters - 1)
                                val isDownloaded = chapters.getOrNull(listIdx)?.url in downloadedChapterUrls

                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .fillMaxHeight(if (inRange) 0.85f else 0.45f)
                                        .clip(RoundedCornerShape(1.dp))
                                        .background(
                                            when {
                                                isDownloaded -> Color(0xFF1E88E5) // blue = downloaded
                                                inRange -> MaterialTheme.colorScheme.primary
                                                else -> Color.White.copy(alpha = 0.18f)
                                            }
                                        )
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Min / Max chapter number indicators
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Min (left)
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                        ) {
                            Text(
                                "Ch. $minChapNum",
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }

                        Text(
                            "${maxChapNum - minChapNum + 1} chương",
                            fontSize = 11.sp,
                            color = Color.Gray
                        )

                        // Max (right)
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                        ) {
                            Text(
                                "Ch. $maxChapNum",
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    Divider(color = Color.White.copy(alpha = 0.08f))
                    Spacer(modifier = Modifier.height(14.dp))

                    // Action buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Download selected range
                        Button(
                            onClick = {
                                val fromListIdx = chapNumToListIndex(maxChapNum) // newest in range
                                val toListIdx = chapNumToListIndex(minChapNum)   // oldest in range
                                onDownloadSelected(fromListIdx, toListIdx)
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.primary
                            )
                        ) {
                            Icon(Icons.Default.FileDownload, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Tải đã chọn", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }

                        // Download all
                        OutlinedButton(
                            onClick = onDownloadAll,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.DownloadForOffline, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Tải toàn bộ", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
