package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.Dispatchers
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.foundation.text.ClickableText
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.data.download.DownloadState
import com.example.data.download.MangaDownloadService
import com.example.data.model.ChapterItem
import com.example.ui.viewmodel.DetailViewModel

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun DetailScreen(
    viewModel: DetailViewModel,
    mangaUrlSlug: String,
    onBackClick: () -> Unit,
    onReadChapterClick: (ChapterItem) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val cleanSlug = remember(mangaUrlSlug) {
        var base = mangaUrlSlug.removePrefix("truyen-tranh/").removePrefix("/")
        for (marker in listOf("/chapter-", "-chapter-", "/chap-", "-chap-", "/chapter", "-chapter", "/chap", "-chap")) {
            if (base.contains(marker)) {
                base = base.substringBefore(marker)
                break
            }
        }
        base
    }
    
    // Trigger loading once the slug is resolved
    LaunchedEffect(cleanSlug) {
        viewModel.loadMangaDetail("truyen-tranh/$cleanSlug")
    }

    val mangaDetail by viewModel.mangaDetail.collectAsStateWithLifecycle()
    val isLoading by viewModel.isLoading.collectAsStateWithLifecycle()
    val isFavorite by viewModel.isFavorite.collectAsStateWithLifecycle()
    val lastReadChapterState by viewModel.lastReadChapter.collectAsStateWithLifecycle()
    val readChapterUrls by viewModel.readChapterUrls.collectAsStateWithLifecycle()

    // Download state
    val isDownloading by DownloadState.isDownloading.collectAsStateWithLifecycle()
    val downloadProgress by DownloadState.progress.collectAsStateWithLifecycle()
    val downloadingChapterName by DownloadState.currentChapterName.collectAsStateWithLifecycle()
    val downloadedChapterUrls by DownloadState.downloadedChapterUrls.collectAsStateWithLifecycle()

    var showDownloadDialog by remember { mutableStateOf(false) }
    var isDeletingDownloads by remember { mutableStateOf(false) }
    val deleteScope = rememberCoroutineScope()

    // Compute downloaded chapters for this manga
    val chaptersForDownload = mangaDetail?.chapters ?: emptyList()
    val hasAnyDownload = remember(downloadedChapterUrls, chaptersForDownload) {
        chaptersForDownload.any { it.url in downloadedChapterUrls }
    }

    // Refresh downloaded chapter state when detail loads — file I/O must run on IO thread
    LaunchedEffect(mangaDetail) {
        val detail = mangaDetail ?: return@LaunchedEffect
        val pairs = detail.chapters.map { it.url to it.name }
        val downloaded = withContext(Dispatchers.IO) {
            MangaDownloadService.getDownloadedChapterUrls(detail.title, pairs)
        }
        DownloadState.setDownloadedChapters(downloaded)
    }

    // Permission launcher for notifications (Android 13+)
    val notifPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { /* proceed regardless */ }

    fun launchDownload(chapterSublist: List<ChapterItem>) {
        if (chapterSublist.isEmpty()) return
        val detail = mangaDetail ?: return
        // Request notification permission on Android 13+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
                notifPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
        MangaDownloadService.startDownload(
            context = context,
            mangaTitle = detail.title,
            chapterUrls = chapterSublist.map { it.url },
            chapterNames = chapterSublist.map { it.name },
            mangaCoverUrl = detail.coverUrl,
            mangaUrl = detail.url,
            mangaSlug = detail.slug,
            mangaDescription = detail.description
        )
        Toast.makeText(context, "Đang tải ${chapterSublist.size} chương trong nền...", Toast.LENGTH_SHORT).show()
    }

    var chapterSearchQuery by remember { mutableStateOf("") }
    var isSortReverse by remember { mutableStateOf(false) }
    var isChapterSearchVisible by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("", maxLines = 1, overflow = TextOverflow.Ellipsis) },
                navigationIcon = {
                    IconButton(
                        onClick = onBackClick,
                        modifier = Modifier
                            .background(Color.Black.copy(alpha = 0.4f), RoundedCornerShape(24.dp))
                    ) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Trở về", tint = Color.White)
                    }
                },
                actions = {
                    // Delete downloads button (only shown if there are downloads)
                    if (hasAnyDownload) {
                        IconButton(
                            onClick = {
                                val detail = mangaDetail ?: return@IconButton
                                if (isDeletingDownloads) return@IconButton
                                isDeletingDownloads = true
                                deleteScope.launch {
                                    withContext(Dispatchers.IO) {
                                        MangaDownloadService.deleteAllDownloads(detail.title)
                                    }
                                    DownloadState.setDownloadedChapters(emptySet())
                                    isDeletingDownloads = false
                                    Toast.makeText(context, "Đã xóa bản tải xuống", Toast.LENGTH_SHORT).show()
                                }
                            },
                            modifier = Modifier
                                .background(Color.Black.copy(alpha = 0.4f), RoundedCornerShape(24.dp))
                        ) {
                            if (isDeletingDownloads) {
                                CircularProgressIndicator(
                                    modifier = androidx.compose.ui.Modifier.size(20.dp),
                                    strokeWidth = 2.dp,
                                    color = MaterialTheme.colorScheme.error
                                )
                            } else {
                                Icon(
                                    imageVector = Icons.Default.DeleteForever,
                                    contentDescription = "Xóa bản tải",
                                    tint = MaterialTheme.colorScheme.error
                                )
                            }
                        }
                    }

                    // Download button
                    IconButton(
                        onClick = {
                            if (isDownloading) {
                                showDownloadDialog = true // show progress
                            } else {
                                showDownloadDialog = true
                            }
                        },
                        modifier = Modifier
                            .background(Color.Black.copy(alpha = 0.4f), RoundedCornerShape(24.dp))
                    ) {
                        Icon(
                            imageVector = if (isDownloading) Icons.Default.Downloading else Icons.Default.Download,
                            contentDescription = "Tải xuống",
                            tint = if (isDownloading) MaterialTheme.colorScheme.primary else Color.White
                        )
                    }

                    // Favorite button
                    IconButton(
                        onClick = { viewModel.toggleFavorite() },
                        modifier = Modifier
                            .background(Color.Black.copy(alpha = 0.4f), RoundedCornerShape(24.dp))
                            .testTag("favorite_toggle_btn")
                    ) {
                        Icon(
                            imageVector = if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            contentDescription = "Yêu thích",
                            tint = if (isFavorite) MaterialTheme.colorScheme.primary else Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.Transparent,
                    scrolledContainerColor = Color.Transparent
                )
            )
        },
        modifier = modifier
    ) { paddingValues ->
        val detail = mangaDetail
        val lastReadChapter = lastReadChapterState

        if (isLoading && detail == null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
            }
        } else if (detail == null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background)
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.Error,
                        contentDescription = null,
                        modifier = Modifier.size(48.dp),
                        tint = MaterialTheme.colorScheme.error
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("Không thể tải thông tin truyện", fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("Nguồn truyện này có thể bị lỗi, hãy thử lại sau nha.", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(modifier = Modifier.height(16.dp))
                    Button(onClick = { viewModel.loadMangaDetail("truyen-tranh/$cleanSlug") }) {
                        Text("Thử Lại")
                    }
                }
            }
        } else {
            // Filter and sort chapters securely from stable local copy
            val filteredChapters = remember(detail.chapters, chapterSearchQuery, isSortReverse) {
                val base = detail.chapters.filter {
                    it.name.lowercase().contains(chapterSearchQuery.lowercase())
                }
                if (isSortReverse) base.reversed() else base
            }

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background)
            ) {
                // Background blurry cover banner
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(310.dp)
                ) {
                    val blurRequest = remember(detail.coverUrl) {
                        val isLocal = detail.coverUrl.startsWith("file://")
                        val builder = ImageRequest.Builder(context).data(detail.coverUrl)
                        if (!isLocal) builder.addHeader("Referer", "https://luottruyen6.com/")
                        builder.build()
                    }
                    AsyncImage(
                        model = blurRequest,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxSize()
                            .blur(20.dp)
                    )
                    // Gradient overlay to fade to solid background
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(
                                        Color.Black.copy(alpha = 0.3f),
                                        MaterialTheme.colorScheme.background
                                    )
                                )
                            )
                    )
                }

                // Main Content List
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(top = 90.dp, bottom = 40.dp)
                ) {
                    // 1. Header Card Info
                    item {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.Bottom
                            ) {
                                // Cover Art Image
                                val coverRequest = remember(detail.coverUrl) {
                                    val isLocal = detail.coverUrl.startsWith("file://")
                                    val builder = ImageRequest.Builder(context)
                                        .data(detail.coverUrl)
                                        .crossfade(true)
                                    if (!isLocal) builder.addHeader("Referer", "https://luottruyen6.com/")
                                    builder.build()
                                }
                                AsyncImage(
                                    model = coverRequest,
                                    contentDescription = detail.title,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .size(width = 110.dp, height = 158.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .border(2.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(12.dp))
                                        .background(MaterialTheme.colorScheme.surfaceVariant)
                                )

                                Spacer(modifier = Modifier.width(16.dp))

                                Column(
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text(
                                        text = detail.title,
                                        style = MaterialTheme.typography.titleLarge,
                                        fontWeight = FontWeight.Black,
                                        color = MaterialTheme.colorScheme.onBackground,
                                        maxLines = 3,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    if (detail.alternativeTitle.isNotBlank()) {
                                        Text(
                                            text = "Tên khác: " + detail.alternativeTitle,
                                            fontSize = 12.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            maxLines = 2,
                                            overflow = TextOverflow.Ellipsis,
                                            modifier = Modifier.padding(top = 4.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(6.dp))
                                    if (detail.ratingAverage.isNotBlank()) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier.padding(top = 4.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Star,
                                                contentDescription = "Xếp hạng",
                                                tint = Color(0xFFFFC107),
                                                modifier = Modifier.size(15.dp)
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(
                                                text = "${detail.ratingAverage}/5",
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.onSurface
                                            )
                                            if (detail.ratingCount.isNotBlank()) {
                                                val countText = if (detail.ratingCount.lowercase().contains("lượt") || detail.ratingCount.lowercase().contains("view") || detail.ratingCount.lowercase().contains("k")) {
                                                    detail.ratingCount
                                                } else {
                                                    "${detail.ratingCount} lượt"
                                                }
                                                Text(
                                                    text = " ($countText)",
                                                    fontSize = 12.sp,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                        }
                                    }
                                }
                            }

                            // Genre list chips
                            if (detail.genres.isNotEmpty()) {
                                FlowRow(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 14.dp),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    detail.genres.forEach { genre ->
                                        SuggestionChip(
                                            onClick = {},
                                            label = { Text(genre, fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                                            colors = SuggestionChipDefaults.suggestionChipColors(
                                                labelColor = MaterialTheme.colorScheme.primary,
                                                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                                            ),
                                            shape = RoundedCornerShape(12.dp)
                                        )
                                    }
                                }
                            } else {
                                Spacer(modifier = Modifier.height(16.dp))
                            }

                            // Action buttons: "Đọc tiếp" or "Đọc đầu tiên"
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(bottom = 16.dp),
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                // Double action read launchers
                                if (lastReadChapter != null) {
                                    Button(
                                        onClick = {
                                            val matched = detail.chapters.firstOrNull { it.url == lastReadChapter.lastReadChapterUrl }
                                                ?: ChapterItem(url = lastReadChapter.lastReadChapterUrl, name = lastReadChapter.lastReadChapterName)
                                            onReadChapterClick(matched)
                                        },
                                        modifier = Modifier
                                            .weight(1.2f)
                                            .height(54.dp),
                                        shape = RoundedCornerShape(16.dp),
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = MaterialTheme.colorScheme.primary,
                                            contentColor = MaterialTheme.colorScheme.onPrimary
                                        ),
                                        elevation = ButtonDefaults.buttonElevation(defaultElevation = 4.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.PlayArrow,
                                            contentDescription = null,
                                            modifier = Modifier.size(20.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "Đọc tiếp " + lastReadChapter.lastReadChapterName,
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.Bold,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }

                                    Button(
                                        onClick = {
                                            // Pick first chapter sequentially (oldest).
                                            val firstChap = detail.chapters.lastOrNull()
                                            if (firstChap != null) onReadChapterClick(firstChap)
                                        },
                                        modifier = Modifier
                                            .weight(0.8f)
                                            .height(54.dp),
                                        shape = RoundedCornerShape(16.dp),
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = MaterialTheme.colorScheme.surfaceVariant,
                                            contentColor = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.MenuBook,
                                            contentDescription = null,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "Đọc từ đầu",
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                } else {
                                    Button(
                                        onClick = {
                                            // Pick first chapter sequentially (oldest).
                                            val firstChap = detail.chapters.lastOrNull()
                                            if (firstChap != null) onReadChapterClick(firstChap)
                                        },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(54.dp),
                                        shape = RoundedCornerShape(16.dp),
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = MaterialTheme.colorScheme.primary,
                                            contentColor = MaterialTheme.colorScheme.onPrimary
                                        ),
                                        elevation = ButtonDefaults.buttonElevation(defaultElevation = 4.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.PlayArrow,
                                            contentDescription = null,
                                            modifier = Modifier.size(20.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "Đọc từ đầu truyện",
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // 2. Summary Expandable block
                    item {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp)
                        ) {
                            Text(
                                "Mô tả nội dung",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = MaterialTheme.colorScheme.surface,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                val descWords = detail.description.trim().split("\\s+".toRegex())
                                var isDescExpanded by remember { mutableStateOf(false) }
                                val previewWords = descWords.take(30)
                                val previewText = previewWords.joinToString(" ")
                                val isLong = descWords.size > 30

                                if (!isLong) {
                                    Text(
                                        text = detail.description,
                                        fontSize = 13.sp,
                                        lineHeight = 20.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.padding(12.dp)
                                    )
                                } else {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        if (isDescExpanded) {
                                            Text(
                                                text = detail.description,
                                                fontSize = 13.sp,
                                                lineHeight = 20.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            )
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(
                                                text = "Thu gọn",
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.SemiBold,
                                                color = Color(0xFF7C4DFF),
                                                modifier = Modifier.clickable { isDescExpanded = false }
                                            )
                                        } else {
                                            ClickableText(
                                                    text = buildAnnotatedString {
                                                        withStyle(
                                                            style = SpanStyle(
                                                                fontSize = 13.sp,
                                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                                            )
                                                        ) { append("$previewText... ") }
                                                        withStyle(
                                                            style = SpanStyle(
                                                                fontSize = 13.sp,
                                                                fontWeight = FontWeight.SemiBold,
                                                                color = Color(0xFF7C4DFF)
                                                            )
                                                        ) { append("Xem thêm") }
                                                    },
                                                    onClick = { isDescExpanded = true }
                                                )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // 3. Chapters Header section
                    item {
                        Spacer(modifier = Modifier.height(24.dp))
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    "Danh sách chương (${filteredChapters.size})",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onBackground
                                )
                                Row(horizontalArrangement = Arrangement.spacedBy(0.dp)) {
                                    // Nút kính lúp — mở/đóng ô lọc chương
                                    IconButton(
                                        onClick = {
                                            isChapterSearchVisible = !isChapterSearchVisible
                                            if (!isChapterSearchVisible) chapterSearchQuery = ""
                                        }
                                    ) {
                                        Icon(
                                            imageVector = if (isChapterSearchVisible) Icons.Default.SearchOff else Icons.Default.Search,
                                            contentDescription = "Tìm chương",
                                            tint = if (isChapterSearchVisible) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    IconButton(
                                        onClick = { isSortReverse = !isSortReverse }
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.SwapVert,
                                            contentDescription = "Đảo chiều",
                                            tint = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                }
                            }

                            // Ô lọc chương — chỉ hiện khi isChapterSearchVisible = true
                            androidx.compose.animation.AnimatedVisibility(
                                visible = isChapterSearchVisible,
                                enter = androidx.compose.animation.expandVertically() + androidx.compose.animation.fadeIn(),
                                exit = androidx.compose.animation.shrinkVertically() + androidx.compose.animation.fadeOut()
                            ) {
                                TextField(
                                    value = chapterSearchQuery,
                                    onValueChange = { chapterSearchQuery = it },
                                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(18.dp)) },
                                    trailingIcon = {
                                        if (chapterSearchQuery.isNotEmpty()) {
                                            IconButton(onClick = { chapterSearchQuery = "" }) {
                                                Icon(Icons.Default.Clear, contentDescription = null, modifier = Modifier.size(18.dp))
                                            }
                                        }
                                    },
                                    placeholder = { Text("Lọc nhanh chương...", fontSize = 13.sp) },
                                    singleLine = true,
                                    shape = RoundedCornerShape(10.dp),
                                    colors = TextFieldDefaults.colors(
                                        focusedIndicatorColor = Color.Transparent,
                                        unfocusedIndicatorColor = Color.Transparent
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 8.dp)
                                        .height(56.dp)
                                )
                            }
                        }
                    }

                    // 4. Chapter lists items representation
                    if (filteredChapters.isEmpty()) {
                        item {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 40.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    "Hình như không có chương nào phù hợp.",
                                    fontSize = 13.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    } else {
                        itemsIndexed(filteredChapters, key = { _, chap -> chap.url }) { _, chapterItem ->
                            ChapterRowItem(
                                chapter = chapterItem,
                                isRead = chapterItem.url in readChapterUrls,
                                isDownloaded = chapterItem.url in downloadedChapterUrls,
                                onClick = { onReadChapterClick(chapterItem) }
                            )
                        }
                    }
                }
            }
        }
    }

    // ===== DOWNLOAD DIALOG =====
    if (showDownloadDialog) {
        val detail = mangaDetail
        if (detail != null) {
            DownloadChapterDialog(
                chapters = detail.chapters,
                mangaTitle = detail.title,
                downloadedChapterUrls = downloadedChapterUrls,
                isDownloading = isDownloading,
                downloadProgress = downloadProgress,
                downloadingChapterName = downloadingChapterName,
                onDownloadSelected = { fromIdx, toIdx ->
                    val range = if (fromIdx <= toIdx) {
                        detail.chapters.subList(fromIdx, toIdx + 1)
                    } else {
                        detail.chapters.subList(toIdx, fromIdx + 1)
                    }
                    launchDownload(range)
                    showDownloadDialog = false
                },
                onDownloadAll = {
                    launchDownload(detail.chapters)
                    showDownloadDialog = false
                },
                onCancel = {
                    MangaDownloadService.cancelDownload(context)
                },
                onDismiss = { showDownloadDialog = false }
            )
        }
    }
}

@Composable
fun ChapterRowItem(
    chapter: ChapterItem,
    isRead: Boolean,
    isDownloaded: Boolean = false,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 4.dp)
            .clickable(onClick = onClick)
            .testTag("chapter_item_${chapter.id.replace("/", "_").replace("-", "_")}"),
        colors = CardDefaults.cardColors(
            containerColor = if (isRead) MaterialTheme.colorScheme.primary.copy(alpha = 0.08f) else MaterialTheme.colorScheme.surface
        ),
        shape = RoundedCornerShape(10.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    chapter.name,
                    fontWeight = if (isRead) FontWeight.ExtraBold else FontWeight.Medium,
                    fontSize = 14.sp,
                    color = if (isRead) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                if (chapter.uploadedAt.isNotBlank()) {
                    Text(
                        chapter.uploadedAt,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }
            }
            
            Row(verticalAlignment = Alignment.CenterVertically) {
                // Downloaded icon
                if (isDownloaded) {
                    Icon(
                        imageVector = Icons.Default.OfflinePin,
                        contentDescription = "Đã tải xuống",
                        tint = Color(0xFF1E88E5),
                        modifier = Modifier
                            .size(16.dp)
                            .padding(end = 0.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                }
                if (isRead) {
                    Text(
                        "Đã đọc",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(end = 6.dp)
                    )
                }
                Icon(
                    Icons.Default.ChevronRight,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                )
            }
        }
    }
}
