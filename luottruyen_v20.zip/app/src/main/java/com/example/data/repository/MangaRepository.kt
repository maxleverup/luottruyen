package com.example.data.repository

import android.util.Log
import com.example.data.db.CachedDetailDao
import com.example.data.db.FavoriteDao
import com.example.data.db.HistoryDao
import com.example.data.db.ReadChapterDao
import com.example.data.model.CachedMangaDetail
import com.example.data.model.FavoriteManga
import com.example.data.model.MangaDetail
import com.example.data.model.MangaItem
import com.example.data.model.ReadChapterRecord
import com.example.data.model.ReadingHistory
import com.example.data.scraper.MangaScraper
import com.example.data.util.MangaDetailSerializer
import kotlinx.coroutines.flow.Flow

class MangaRepository(
    private val favoriteDao: FavoriteDao,
    private val historyDao: HistoryDao,
    private val cachedDetailDao: CachedDetailDao,
    private val readChapterDao: ReadChapterDao
) {
    // In-memory cache for MangaItems fetched during current session
    private val mangaCache = java.util.concurrent.ConcurrentHashMap<String, MangaItem>()

    private fun cacheMangaItems(items: List<MangaItem>) {
        items.forEach { item -> mangaCache[item.slug] = item }
    }

    // Network Scraper Methods
    suspend fun getLatestManga(page: Int = 1): List<MangaItem> {
        val items = MangaScraper.getLatestManga(page)
        cacheMangaItems(items)
        return items
    }

    suspend fun searchManga(keyword: String, page: Int = 1): List<MangaItem> {
        if (keyword.isBlank()) return emptyList()
        val items = MangaScraper.searchManga(keyword, page)
        cacheMangaItems(items)
        return items
    }

    suspend fun getMangaByCategory(categoryUrl: String, page: Int = 1): List<MangaItem> {
        val items = MangaScraper.getMangaByCategory(categoryUrl, page)
        cacheMangaItems(items)
        return items
    }

    /**
     * Fetches MangaDetail. If online fetch fails, falls back to DB cache.
     * On success, always saves/updates the cache in DB.
     */
    suspend fun getMangaDetail(relativeUrl: String): MangaDetail {
        // Compute slug from relativeUrl to look up cache
        val slug = relativeUrl
            .substringAfter("luottruyen6.com/")
            .removePrefix("/")
            .substringBefore("?")
            .trimEnd('/')

        return try {
            val detail = MangaScraper.getMangaDetail(relativeUrl)

            // Merge in-memory rating cache
            val cached = mangaCache[detail.slug]
            val merged = if (cached != null) {
                val finalRating = if (detail.ratingAverage == "0.0" || detail.ratingAverage.isBlank()) cached.rating else detail.ratingAverage
                val finalCount  = if (detail.ratingCount  == "0"   || detail.ratingCount.isBlank())   cached.views  else detail.ratingCount
                detail.copy(
                    ratingAverage = finalRating.ifBlank { "0.0" },
                    ratingCount   = finalCount.ifBlank  { "0"   }
                )
            } else detail

            // Persist to DB cache so it's available offline
            saveCachedDetail(merged)

            merged
        } catch (e: Exception) {
            Log.w("MangaRepository", "Online fetch failed for $relativeUrl, trying DB cache", e)
            // Fall back to cached detail in DB
            val dbCached = cachedDetailDao.getBySlug(slug)
            if (dbCached != null) {
                val detail = MangaDetailSerializer.fromJson(dbCached.detailJson)
                if (detail != null) {
                    // Patch coverUrl to local file if available
                    val localCover = dbCached.coverLocalPath
                    return if (localCover.isNotEmpty()) detail.copy(coverUrl = "file://$localCover")
                    else detail
                }
            }
            throw e // No cache available, rethrow
        }
    }

    /** Saves detail JSON + local cover path into DB */
    suspend fun saveCachedDetail(detail: MangaDetail, coverLocalPath: String = "") {
        try {
            val existing = cachedDetailDao.getBySlug(detail.slug)
            val coverPath = coverLocalPath.ifEmpty { existing?.coverLocalPath ?: "" }
            cachedDetailDao.insert(
                CachedMangaDetail(
                    slug = detail.slug,
                    detailJson = MangaDetailSerializer.toJson(detail),
                    coverLocalPath = coverPath
                )
            )
        } catch (e: Exception) {
            Log.e("MangaRepository", "Failed to cache detail for ${detail.slug}", e)
        }
    }

    /** Updates only the cover local path in an existing cache entry */
    suspend fun updateCachedCover(slug: String, coverLocalPath: String) {
        try {
            val existing = cachedDetailDao.getBySlug(slug) ?: return
            cachedDetailDao.insert(existing.copy(coverLocalPath = coverLocalPath))
        } catch (e: Exception) {
            Log.e("MangaRepository", "Failed to update cover for $slug", e)
        }
    }

    suspend fun getChapterImages(chapterUrl: String): List<String> {
        return MangaScraper.getChapterImages(chapterUrl)
    }

    /**
     * Returns local file:// URIs if chapter is downloaded, else fetches online.
     */
    suspend fun getChapterImagesWithOffline(
        chapterUrl: String,
        mangaTitle: String,
        chapterName: String
    ): List<String> {
        val dir = com.example.data.download.MangaDownloadService.getChapterDownloadDir(mangaTitle, chapterName)
        if (dir.exists()) {
            val files = dir.listFiles()
                ?.filter { it.extension.lowercase() in listOf("jpg", "jpeg", "png", "webp") }
                ?.sortedBy { it.name }
            if (!files.isNullOrEmpty()) {
                return files.map { "file://${it.absolutePath}" }
            }
        }
        return MangaScraper.getChapterImages(chapterUrl)
    }

    suspend fun getAvailableGenres(): List<Pair<String, String>> {
        return MangaScraper.getAvailableGenres()
    }

    // Favorites Local DB Methods
    fun getAllFavorites(): Flow<List<FavoriteManga>> = favoriteDao.getAllFavorites()

    suspend fun isFavorite(slug: String): Boolean = favoriteDao.isFavorite(slug)

    suspend fun addFavorite(favorite: FavoriteManga) {
        favoriteDao.insertFavorite(favorite)
    }

    suspend fun removeFavoriteBySlug(slug: String) {
        favoriteDao.deleteFavoriteBySlug(slug)
    }

    // History Local DB Methods
    fun getReadingHistory(): Flow<List<ReadingHistory>> = historyDao.getReadingHistory()

    suspend fun getHistoryBySlug(slug: String): ReadingHistory? {
        return historyDao.getHistoryBySlug(slug)
    }

    suspend fun saveHistory(history: ReadingHistory) {
        historyDao.insertHistory(history)
    }

    suspend fun deleteHistoryBySlug(slug: String) {
        historyDao.deleteHistoryBySlug(slug)
    }

    suspend fun clearHistory() {
        historyDao.clearHistory()
    }

    // Read chapter tracking
    suspend fun markChapterRead(mangaSlug: String, chapterUrl: String, chapterName: String) {
        readChapterDao.markRead(ReadChapterRecord(mangaSlug, chapterUrl, chapterName))
    }

    suspend fun getReadChapterUrls(mangaSlug: String): Set<String> {
        return readChapterDao.getReadChapterUrls(mangaSlug).toSet()
    }
}
