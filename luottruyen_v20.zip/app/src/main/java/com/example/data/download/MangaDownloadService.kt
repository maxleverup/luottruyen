package com.example.data.download

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Environment
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.data.AppSettings
import com.example.data.scraper.MangaScraper
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.security.SecureRandom
import java.security.cert.X509Certificate
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager

// Singleton state so UI can observe from anywhere
object DownloadState {
    private val _isDownloading = MutableStateFlow(false)
    val isDownloading: StateFlow<Boolean> = _isDownloading.asStateFlow()

    private val _progress = MutableStateFlow(0f) // 0..1
    val progress: StateFlow<Float> = _progress.asStateFlow()

    private val _currentChapterName = MutableStateFlow("")
    val currentChapterName: StateFlow<String> = _currentChapterName.asStateFlow()

    private val _downloadedChapterUrls = MutableStateFlow<Set<String>>(emptySet())
    val downloadedChapterUrls: StateFlow<Set<String>> = _downloadedChapterUrls.asStateFlow()

    // cancelled flag
    var cancelRequested = false

    fun update(isDownloading: Boolean, progress: Float = 0f, chapterName: String = "") {
        _isDownloading.value = isDownloading
        _progress.value = progress
        _currentChapterName.value = chapterName
    }

    fun setDownloadedChapters(urls: Set<String>) {
        _downloadedChapterUrls.value = urls
    }

    fun addDownloadedChapter(url: String) {
        _downloadedChapterUrls.value = _downloadedChapterUrls.value + url
    }
}

class MangaDownloadService : Service() {

    companion object {
        const val CHANNEL_ID = "manga_download_channel"
        const val NOTIF_ID = 8001
        const val ACTION_DOWNLOAD = "com.example.ACTION_DOWNLOAD"
        const val ACTION_CANCEL = "com.example.ACTION_CANCEL"
        const val EXTRA_MANGA_TITLE = "manga_title"
        const val EXTRA_MANGA_COVER = "manga_cover"
        const val EXTRA_MANGA_URL = "manga_url"
        const val EXTRA_MANGA_SLUG = "manga_slug"
        const val EXTRA_MANGA_DESC = "manga_desc"
        const val EXTRA_CHAPTER_URLS = "chapter_urls"
        const val EXTRA_CHAPTER_NAMES = "chapter_names"
        private const val TAG = "MangaDownloadService"

        fun startDownload(
            context: Context,
            mangaTitle: String,
            chapterUrls: List<String>,
            chapterNames: List<String>,
            mangaCoverUrl: String = "",
            mangaUrl: String = "",
            mangaSlug: String = "",
            mangaDescription: String = ""
        ) {
            val intent = Intent(context, MangaDownloadService::class.java).apply {
                action = ACTION_DOWNLOAD
                putExtra(EXTRA_MANGA_TITLE, mangaTitle)
                putExtra(EXTRA_MANGA_COVER, mangaCoverUrl)
                putExtra(EXTRA_MANGA_URL, mangaUrl)
                putExtra(EXTRA_MANGA_SLUG, mangaSlug)
                putExtra(EXTRA_MANGA_DESC, mangaDescription)
                putStringArrayListExtra(EXTRA_CHAPTER_URLS, ArrayList(chapterUrls))
                putStringArrayListExtra(EXTRA_CHAPTER_NAMES, ArrayList(chapterNames))
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun cancelDownload(context: Context) {
            DownloadState.cancelRequested = true
            val intent = Intent(context, MangaDownloadService::class.java).apply {
                action = ACTION_CANCEL
            }
            context.startService(intent)
        }

        fun getMangaDownloadDir(mangaTitle: String): File {
            val safeTitle = mangaTitle.replace(Regex("[\\\\/:*?\"<>|]"), "_")
            return File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                "Luottruyen/$safeTitle"
            )
        }

        fun getChapterDownloadDir(mangaTitle: String, chapterName: String): File {
            val safeChap = chapterName.replace(Regex("[\\\\/:*?\"<>|]"), "_")
            return File(getMangaDownloadDir(mangaTitle), safeChap)
        }

        fun isChapterDownloaded(mangaTitle: String, chapterName: String): Boolean {
            val dir = getChapterDownloadDir(mangaTitle, chapterName)
            return dir.exists() && (dir.listFiles()?.isNotEmpty() == true)
        }

        /**
         * Scan the manga download directory ONCE and return all chapter URLs that are present.
         * Single directory listing is O(1) vs O(N) individual exists()+listFiles() calls.
         */
        fun getDownloadedChapterUrls(mangaTitle: String, allChapters: List<Pair<String, String>>): Set<String> {
            val mangaDir = getMangaDownloadDir(mangaTitle)
            if (!mangaDir.exists()) return emptySet()
            // List all sub-directory names in one syscall — O(1) instead of O(N) disk checks
            val existingDirs = mangaDir.list()?.toHashSet() ?: return emptySet()
            return allChapters.filter { (_, name) ->
                // Reuse getChapterDownloadDir to get the exact safe directory name
                val chapDir = getChapterDownloadDir(mangaTitle, name)
                existingDirs.contains(chapDir.name)
            }.map { it.first }.toSet()
        }

        fun deleteAllDownloads(mangaTitle: String): Boolean {
            return try {
                getMangaDownloadDir(mangaTitle).deleteRecursively()
            } catch (e: Exception) {
                false
            }
        }
    }

    private val serviceScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private lateinit var notificationManager: NotificationManager

    private val trustingClient: OkHttpClient by lazy {
        val trustAllCerts = object : X509TrustManager {
            override fun checkClientTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
            override fun checkServerTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
            override fun getAcceptedIssuers(): Array<X509Certificate> = arrayOf()
        }
        val sslContext = SSLContext.getInstance("SSL")
        sslContext.init(null, arrayOf<TrustManager>(trustAllCerts), SecureRandom())
        OkHttpClient.Builder()
            .sslSocketFactory(sslContext.socketFactory, trustAllCerts)
            .hostnameVerifier { _, _ -> true }
            .build()
    }

    override fun onCreate() {
        super.onCreate()
        notificationManager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_CANCEL -> {
                DownloadState.cancelRequested = true
                serviceScope.cancel()
                DownloadState.update(false)
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
            ACTION_DOWNLOAD -> {
                val mangaTitle = intent.getStringExtra(EXTRA_MANGA_TITLE) ?: return START_NOT_STICKY
                val chapterUrls = intent.getStringArrayListExtra(EXTRA_CHAPTER_URLS) ?: return START_NOT_STICKY
                val chapterNames = intent.getStringArrayListExtra(EXTRA_CHAPTER_NAMES) ?: return START_NOT_STICKY
                val mangaCover = intent.getStringExtra(EXTRA_MANGA_COVER) ?: ""
                val mangaUrl = intent.getStringExtra(EXTRA_MANGA_URL) ?: ""
                val mangaSlug = intent.getStringExtra(EXTRA_MANGA_SLUG) ?: ""
                val mangaDesc = intent.getStringExtra(EXTRA_MANGA_DESC) ?: ""
                DownloadState.cancelRequested = false
                startForeground(NOTIF_ID, buildNotification("Đang chuẩn bị tải...", 0, chapterUrls.size, mangaTitle))
                startDownloadJob(mangaTitle, chapterUrls, chapterNames, mangaCover, mangaUrl, mangaSlug, mangaDesc)
            }
        }
        return START_NOT_STICKY
    }

    private fun startDownloadJob(
        mangaTitle: String,
        chapterUrls: List<String>,
        chapterNames: List<String>,
        mangaCover: String = "",
        mangaUrl: String = "",
        mangaSlug: String = "",
        mangaDesc: String = ""
    ) {
        serviceScope.launch {
            val total = chapterUrls.size
            val completedCount = java.util.concurrent.atomic.AtomicInteger(0)
            val scraper = MangaScraper

            // Semaphore to cap concurrent chapter downloads at 20
            val semaphore = Semaphore(20)

            try {
                DownloadState.update(true, 0f, "Đang tải $total chương (20 luồng)...")
                updateNotification("Bắt đầu tải $total chương...", 0, total, mangaTitle)

                // Helper: download a single chapter with verification, returns true if all pages saved
                suspend fun downloadChapter(url: String, name: String): Boolean {
                    return try {
                        val images = scraper.getChapterImages(url)
                        if (images.isEmpty()) {
                            Log.w(TAG, "No images found for chapter $name")
                            return false
                        }
                        val chapDir = getChapterDownloadDir(mangaTitle, name)
                        chapDir.mkdirs()

                        // Download all pages in parallel (up to 5 per chapter)
                        val pageSemaphore = Semaphore(5)
                        val pageJobs = images.mapIndexed { imgIdx, imgUrl ->
                            async(Dispatchers.IO) {
                                pageSemaphore.withPermit {
                                    if (!DownloadState.cancelRequested) {
                                        downloadImage(imgUrl, File(chapDir, "page_${String.format("%03d", imgIdx + 1)}.jpg"))
                                    }
                                }
                            }
                        }
                        pageJobs.forEach { it.await() }

                        // Verify: check that saved file count matches expected page count
                        val savedCount = chapDir.listFiles()?.count { it.extension == "jpg" } ?: 0
                        val verified = savedCount >= images.size
                        if (!verified) {
                            Log.w(TAG, "Chapter $name incomplete: $savedCount/${images.size} pages saved")
                        }
                        verified
                    } catch (e: Exception) {
                        Log.e(TAG, "Failed to download chapter $name", e)
                        false
                    }
                }

                // Launch all chapters concurrently, bounded by semaphore
                val jobs = chapterUrls.indices.map { i ->
                    async(Dispatchers.IO) {
                        if (DownloadState.cancelRequested) return@async
                        semaphore.withPermit {
                            if (DownloadState.cancelRequested) return@withPermit
                            val url = chapterUrls[i]
                            val name = chapterNames[i]

                            // Try up to 3 times
                            var success = false
                            var attempt = 0
                            while (!success && attempt < 3 && !DownloadState.cancelRequested) {
                                attempt++
                                if (attempt > 1) {
                                    Log.d(TAG, "Retry $attempt/3 for chapter $name")
                                    // Clean partial dir before retry
                                    getChapterDownloadDir(mangaTitle, name).deleteRecursively()
                                    delay(1000L * attempt) // back-off: 2s, 3s
                                }
                                success = downloadChapter(url, name)
                            }

                            if (success && !DownloadState.cancelRequested) {
                                val done = completedCount.incrementAndGet()
                                DownloadState.addDownloadedChapter(url)
                                DownloadState.update(true, done.toFloat() / total, "[$done/$total] $name")
                                updateNotification("[$done/$total] $name", done, total, mangaTitle)
                            } else if (!DownloadState.cancelRequested) {
                                Log.e(TAG, "Chapter $name failed after 3 attempts, skipping")
                            }
                        }
                    }
                }

                jobs.forEach { it.await() }

                // Final verification pass: re-queue any chapter whose folder is missing or empty
                if (!DownloadState.cancelRequested) {
                    val failedIndices = chapterUrls.indices.filter { i ->
                        val chapDir = getChapterDownloadDir(mangaTitle, chapterNames[i])
                        !chapDir.exists() || (chapDir.listFiles()?.isEmpty() == true)
                    }
                    if (failedIndices.isNotEmpty()) {
                        Log.w(TAG, "${failedIndices.size} chapters missing after first pass — retrying...")
                        updateNotification("Kiểm tra lại ${failedIndices.size} chương thiếu...", completedCount.get(), total, mangaTitle)
                        val retryJobs = failedIndices.map { i ->
                            async(Dispatchers.IO) {
                                if (DownloadState.cancelRequested) return@async
                                semaphore.withPermit {
                                    if (DownloadState.cancelRequested) return@withPermit
                                    val url = chapterUrls[i]
                                    val name = chapterNames[i]
                                    var success = false
                                    var attempt = 0
                                    while (!success && attempt < 3 && !DownloadState.cancelRequested) {
                                        attempt++
                                        getChapterDownloadDir(mangaTitle, name).deleteRecursively()
                                        delay(500L * attempt)
                                        success = downloadChapter(url, name)
                                    }
                                    if (success && !DownloadState.cancelRequested) {
                                        val done = completedCount.incrementAndGet()
                                        DownloadState.addDownloadedChapter(url)
                                        DownloadState.update(true, done.toFloat() / total, "Bù [$done/$total] $name")
                                        updateNotification("Bù [$done/$total] $name", done, total, mangaTitle)
                                    } else if (!DownloadState.cancelRequested) {
                                        Log.e(TAG, "Chapter $name still failed in retry pass")
                                    }
                                }
                            }
                        }
                        retryJobs.forEach { it.await() }
                    }
                }

                // If cancelled, delete all downloaded chapters
                if (DownloadState.cancelRequested) {
                    deletePartialDownloads(mangaTitle, chapterNames)
                }

            } finally {
                val cancelled = DownloadState.cancelRequested
                val completed = completedCount.get()
                val msg = if (cancelled) "Đã hủy tải" else "Tải xong $completed/$total chương"
                DownloadState.update(false, 1f, msg)
                updateNotification(msg, total, total, mangaTitle, done = true)

                // Auto-add to favorites when download completes successfully
                if (!cancelled && completed > 0 && mangaSlug.isNotEmpty()) {
                    try {
                        val db = com.example.data.db.MangaDatabase.getDatabase(applicationContext)

                        // Download cover image locally
                        var localCoverPath = ""
                        if (mangaCover.isNotEmpty()) {
                            val coverDir = getMangaDownloadDir(mangaTitle)
                            coverDir.mkdirs()
                            val coverFile = java.io.File(coverDir, "cover.jpg")
                            if (!coverFile.exists()) {
                                downloadImage(mangaCover, coverFile)
                            }
                            if (coverFile.exists()) localCoverPath = coverFile.absolutePath
                        }

                        // Save/update detail cache with local cover
                        val cachedEntry = db.cachedDetailDao().getBySlug(mangaSlug)
                        if (cachedEntry != null && localCoverPath.isNotEmpty()) {
                            db.cachedDetailDao().insert(cachedEntry.copy(coverLocalPath = localCoverPath))
                        }

                        // Auto-add to favorites
                        val fav = com.example.data.model.FavoriteManga(
                            slug = mangaSlug,
                            url = mangaUrl,
                            title = mangaTitle,
                            coverUrl = if (localCoverPath.isNotEmpty()) "file://$localCoverPath" else mangaCover,
                            description = mangaDesc,
                            isDownloaded = true
                        )
                        db.favoriteDao().insertFavorite(fav)
                        Log.d(TAG, "Auto-added $mangaTitle to favorites after download")
                    } catch (e: Exception) {
                        Log.e(TAG, "Failed to auto-add favorite", e)
                    }
                }

                delay(3000)
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }
    }

    private fun deletePartialDownloads(mangaTitle: String, chapterNames: List<String>) {
        chapterNames.forEach { name ->
            try { getChapterDownloadDir(mangaTitle, name).deleteRecursively() } catch (_: Exception) {}
        }
    }

    private fun downloadImage(url: String, dest: File) {
        if (dest.exists()) return
        try {
            val referer = AppSettings.baseUrl.let { if (it.endsWith("/")) it else "$it/" }
            val req = Request.Builder()
                .url(url)
                .addHeader("Referer", referer)
                .addHeader("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64)")
                .build()
            trustingClient.newCall(req).execute().use { resp ->
                if (resp.isSuccessful) {
                    resp.body?.byteStream()?.use { input ->
                        dest.outputStream().use { output -> input.copyTo(output) }
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Image download failed: $url", e)
        }
    }

    private fun buildNotification(text: String, current: Int, total: Int, mangaTitle: String, done: Boolean = false): android.app.Notification {
        val cancelIntent = Intent(this, MangaDownloadService::class.java).apply { action = ACTION_CANCEL }
        val cancelPi = PendingIntent.getService(this, 0, cancelIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(if (done) "Tải truyện hoàn tất" else "Đang tải: $mangaTitle")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setProgress(total, current, !done && current == 0)
            .setOngoing(!done)
            .apply {
                if (!done) addAction(android.R.drawable.ic_menu_close_clear_cancel, "Hủy", cancelPi)
            }
            .build()
    }

    private fun updateNotification(chapterName: String, current: Int, total: Int, mangaTitle: String, done: Boolean = false) {
        val notif = buildNotification(
            if (done) "Hoàn thành $current/$total chương" else "[$current/$total] $chapterName",
            current, total, mangaTitle, done
        )
        notificationManager.notify(NOTIF_ID, notif)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Tải Truyện",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Thông báo tiến trình tải truyện tranh"
                setShowBadge(false)
            }
            notificationManager.createNotificationChannel(channel)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
    }
}
