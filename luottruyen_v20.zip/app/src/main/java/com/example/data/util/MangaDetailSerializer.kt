package com.example.data.util

import com.example.data.model.ChapterItem
import com.example.data.model.MangaDetail
import org.json.JSONArray
import org.json.JSONObject

object MangaDetailSerializer {

    fun toJson(detail: MangaDetail): String {
        val obj = JSONObject()
        obj.put("url", detail.url)
        obj.put("title", detail.title)
        obj.put("coverUrl", detail.coverUrl)
        obj.put("description", detail.description)
        obj.put("alternativeTitle", detail.alternativeTitle)
        obj.put("authors", detail.authors)
        obj.put("status", detail.status)
        obj.put("ratingAverage", detail.ratingAverage)
        obj.put("ratingCount", detail.ratingCount)

        val genresArr = JSONArray()
        detail.genres.forEach { genresArr.put(it) }
        obj.put("genres", genresArr)

        val chaptersArr = JSONArray()
        detail.chapters.forEach { chap ->
            val chapObj = JSONObject()
            chapObj.put("url", chap.url)
            chapObj.put("name", chap.name)
            chapObj.put("uploadedAt", chap.uploadedAt)
            chaptersArr.put(chapObj)
        }
        obj.put("chapters", chaptersArr)

        return obj.toString()
    }

    fun fromJson(json: String): MangaDetail? {
        return try {
            val obj = JSONObject(json)

            val genres = mutableListOf<String>()
            val genresArr = obj.optJSONArray("genres")
            if (genresArr != null) {
                for (i in 0 until genresArr.length()) {
                    genres.add(genresArr.getString(i))
                }
            }

            val chapters = mutableListOf<ChapterItem>()
            val chaptersArr = obj.optJSONArray("chapters")
            if (chaptersArr != null) {
                for (i in 0 until chaptersArr.length()) {
                    val chapObj = chaptersArr.getJSONObject(i)
                    chapters.add(
                        ChapterItem(
                            url = chapObj.optString("url"),
                            name = chapObj.optString("name"),
                            uploadedAt = chapObj.optString("uploadedAt")
                        )
                    )
                }
            }

            MangaDetail(
                url = obj.optString("url"),
                title = obj.optString("title"),
                coverUrl = obj.optString("coverUrl"),
                description = obj.optString("description"),
                alternativeTitle = obj.optString("alternativeTitle"),
                authors = obj.optString("authors"),
                status = obj.optString("status"),
                ratingAverage = obj.optString("ratingAverage"),
                ratingCount = obj.optString("ratingCount"),
                genres = genres,
                chapters = chapters
            )
        } catch (e: Exception) {
            null
        }
    }
}
