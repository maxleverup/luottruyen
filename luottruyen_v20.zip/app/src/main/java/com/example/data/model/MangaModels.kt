package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.io.Serializable

data class MangaItem(
    val url: String, // Full URL or relative URL slug
    val title: String,
    val coverUrl: String,
    val rating: String = "",
    val views: String = "",
    val latestChapter: String = ""
) : Serializable {
    val slug: String
        get() = url.substringAfter("luottruyen6.com/").removePrefix("/")
}

data class ChapterItem(
    val url: String, // Full URL of the chapter
    val name: String,
    val uploadedAt: String = ""
) : Serializable {
    val id: String
        get() = url.substringAfter("luottruyen6.com/").removePrefix("/")
}

data class MangaDetail(
    val url: String,
    val title: String,
    val coverUrl: String,
    val description: String,
    val alternativeTitle: String = "",
    val authors: String = "",
    val status: String = "",
    val genres: List<String> = emptyList(),
    val chapters: List<ChapterItem> = emptyList(),
    val ratingAverage: String = "",
    val ratingCount: String = ""
) : Serializable {
    val slug: String
        get() = url.substringAfter("luottruyen6.com/").removePrefix("/")
}

// Room Database entities
@Entity(tableName = "favorites")
data class FavoriteManga(
    @PrimaryKey val slug: String,
    val url: String,
    val title: String,
    val coverUrl: String,
    val description: String = "",
    val isDownloaded: Boolean = false,
    val favoritedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "history")
data class ReadingHistory(
    @PrimaryKey val slug: String,
    val title: String,
    val coverUrl: String,
    val lastReadChapterName: String,
    val lastReadChapterUrl: String,
    val mangaUrl: String = "",
    val scrollOffset: Int = 0,
    val lastPageIndex: Int = 0,
    val readAt: Long = System.currentTimeMillis()
)

/** Tracks each chapter that has been fully/partially read */
@Entity(tableName = "read_chapters", primaryKeys = ["mangaSlug", "chapterUrl"])
data class ReadChapterRecord(
    val mangaSlug: String,
    val chapterUrl: String,
    val chapterName: String,
    val readAt: Long = System.currentTimeMillis()
)

/**
 * Stores full MangaDetail as JSON for offline access.
 * coverLocalPath = local file path of cached cover image.
 */
@Entity(tableName = "cached_detail")
data class CachedMangaDetail(
    @PrimaryKey val slug: String,
    val detailJson: String,          // Full MangaDetail serialized as JSON
    val coverLocalPath: String = "", // Local file path of downloaded cover image
    val cachedAt: Long = System.currentTimeMillis()
)
