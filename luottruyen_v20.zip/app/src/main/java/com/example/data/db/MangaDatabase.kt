package com.example.data.db

import android.content.Context
import androidx.room.*
import com.example.data.model.CachedMangaDetail
import com.example.data.model.FavoriteManga
import com.example.data.model.ReadChapterRecord
import com.example.data.model.ReadingHistory
import kotlinx.coroutines.flow.Flow

@Dao
interface FavoriteDao {
    @Query("SELECT * FROM favorites ORDER BY favoritedAt DESC")
    fun getAllFavorites(): Flow<List<FavoriteManga>>

    @Query("SELECT * FROM favorites ORDER BY favoritedAt DESC")
    suspend fun getAllFavoritesSync(): List<FavoriteManga>

    @Query("SELECT EXISTS(SELECT 1 FROM favorites WHERE slug = :slug LIMIT 1)")
    suspend fun isFavorite(slug: String): Boolean

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFavorite(manga: FavoriteManga)

    @Delete
    suspend fun deleteFavorite(manga: FavoriteManga)

    @Query("DELETE FROM favorites WHERE slug = :slug")
    suspend fun deleteFavoriteBySlug(slug: String)
}

@Dao
interface HistoryDao {
    @Query("SELECT * FROM history ORDER BY readAt DESC")
    fun getReadingHistory(): Flow<List<ReadingHistory>>

    @Query("SELECT * FROM history ORDER BY readAt DESC")
    suspend fun getReadingHistorySync(): List<ReadingHistory>

    @Query("SELECT * FROM history WHERE slug = :slug LIMIT 1")
    suspend fun getHistoryBySlug(slug: String): ReadingHistory?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHistory(history: ReadingHistory)

    @Query("DELETE FROM history WHERE slug = :slug")
    suspend fun deleteHistoryBySlug(slug: String)

    @Query("DELETE FROM history")
    suspend fun clearHistory()
}

@Dao
interface CachedDetailDao {
    @Query("SELECT * FROM cached_detail WHERE slug = :slug LIMIT 1")
    suspend fun getBySlug(slug: String): CachedMangaDetail?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(detail: CachedMangaDetail)

    @Query("DELETE FROM cached_detail WHERE slug = :slug")
    suspend fun deleteBySlug(slug: String)
}

@Dao
interface ReadChapterDao {
    @Query("SELECT chapterUrl FROM read_chapters WHERE mangaSlug = :mangaSlug")
    suspend fun getReadChapterUrls(mangaSlug: String): List<String>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun markRead(record: ReadChapterRecord)

    @Query("DELETE FROM read_chapters WHERE mangaSlug = :mangaSlug")
    suspend fun deleteByManga(mangaSlug: String)
}

@Database(
    entities = [FavoriteManga::class, ReadingHistory::class, CachedMangaDetail::class, ReadChapterRecord::class],
    version = 5,
    exportSchema = false
)
abstract class MangaDatabase : RoomDatabase() {
    abstract fun favoriteDao(): FavoriteDao
    abstract fun historyDao(): HistoryDao
    abstract fun cachedDetailDao(): CachedDetailDao
    abstract fun readChapterDao(): ReadChapterDao

    companion object {
        @Volatile
        private var INSTANCE: MangaDatabase? = null

        fun getDatabase(context: Context): MangaDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    MangaDatabase::class.java,
                    "luot_truyen_database"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
