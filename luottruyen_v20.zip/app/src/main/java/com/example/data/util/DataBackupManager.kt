package com.example.data.util

import android.content.Context
import android.os.Environment
import android.util.Log
import com.example.data.AppSettings
import com.example.data.db.MangaDatabase
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

object DataBackupManager {
    private const val TAG = "DataBackupManager"
    private const val BACKUP_FILENAME = "luottruyen_backup.json"

    fun getBackupFile(): File {
        val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        return File(dir, "Luottruyen/$BACKUP_FILENAME")
    }

    suspend fun exportData(context: Context): Result<File> {
        return try {
            val db = MangaDatabase.getDatabase(context)
            val root = JSONObject()

            // 1. Settings
            val settings = JSONObject()
            settings.put("baseUrl", AppSettings.baseUrl)
            settings.put("cookies", AppSettings.cookies)
            settings.put("loggedInUserName", AppSettings.loggedInUserName)
            root.put("settings", settings)

            // 2. Favorites
            val favList = JSONArray()
            db.favoriteDao().getAllFavoritesSync().forEach { fav ->
                val obj = JSONObject()
                obj.put("slug", fav.slug)
                obj.put("url", fav.url)
                obj.put("title", fav.title)
                obj.put("coverUrl", fav.coverUrl)
                obj.put("description", fav.description)
                obj.put("isDownloaded", fav.isDownloaded)
                obj.put("favoritedAt", fav.favoritedAt)
                favList.put(obj)
            }
            root.put("favorites", favList)

            // 3. History
            val histList = JSONArray()
            db.historyDao().getReadingHistorySync().forEach { h ->
                val obj = JSONObject()
                obj.put("slug", h.slug)
                obj.put("title", h.title)
                obj.put("coverUrl", h.coverUrl)
                obj.put("lastReadChapterName", h.lastReadChapterName)
                obj.put("lastReadChapterUrl", h.lastReadChapterUrl)
                obj.put("mangaUrl", h.mangaUrl)
                obj.put("scrollOffset", h.scrollOffset)
                obj.put("lastPageIndex", h.lastPageIndex)
                obj.put("readAt", h.readAt)
                histList.put(obj)
            }
            root.put("history", histList)

            root.put("exportedAt", System.currentTimeMillis())
            root.put("version", 2)

            val file = getBackupFile()
            file.parentFile?.mkdirs()
            file.writeText(root.toString(2))
            Log.d(TAG, "Exported backup to ${file.absolutePath}")
            Result.success(file)
        } catch (e: Exception) {
            Log.e(TAG, "Export failed", e)
            Result.failure(e)
        }
    }

    suspend fun importData(context: Context, file: File): Result<String> {
        return try {
            val json = file.readText()
            val root = JSONObject(json)
            val db = MangaDatabase.getDatabase(context)

            var imported = ""

            // 1. Settings
            root.optJSONObject("settings")?.let { s ->
                val url = s.optString("baseUrl")
                val cookies = s.optString("cookies")
                val user = s.optString("loggedInUserName")
                if (url.isNotEmpty()) AppSettings.baseUrl = url
                if (cookies.isNotEmpty()) AppSettings.cookies = cookies
                if (user.isNotEmpty()) AppSettings.loggedInUserName = user
                imported += "✓ Cài đặt & cookie\n"
            }

            // 2. Favorites
            root.optJSONArray("favorites")?.let { arr ->
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    db.favoriteDao().insertFavorite(
                        com.example.data.model.FavoriteManga(
                            slug = obj.optString("slug"),
                            url = obj.optString("url"),
                            title = obj.optString("title"),
                            coverUrl = obj.optString("coverUrl"),
                            description = obj.optString("description"),
                            isDownloaded = obj.optBoolean("isDownloaded", false),
                            favoritedAt = obj.optLong("favoritedAt", System.currentTimeMillis())
                        )
                    )
                }
                imported += "✓ ${arr.length()} truyện yêu thích\n"
            }

            // 3. History
            root.optJSONArray("history")?.let { arr ->
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    db.historyDao().insertHistory(
                        com.example.data.model.ReadingHistory(
                            slug = obj.optString("slug"),
                            title = obj.optString("title"),
                            coverUrl = obj.optString("coverUrl"),
                            lastReadChapterName = obj.optString("lastReadChapterName"),
                            lastReadChapterUrl = obj.optString("lastReadChapterUrl"),
                            mangaUrl = obj.optString("mangaUrl"),
                            scrollOffset = obj.optInt("scrollOffset", 0),
                            lastPageIndex = obj.optInt("lastPageIndex", 0),
                            readAt = obj.optLong("readAt", System.currentTimeMillis())
                        )
                    )
                }
                imported += "✓ ${arr.length()} lịch sử đọc\n"
            }

            Result.success(imported.trim())
        } catch (e: Exception) {
            Log.e(TAG, "Import failed", e)
            Result.failure(e)
        }
    }
}
