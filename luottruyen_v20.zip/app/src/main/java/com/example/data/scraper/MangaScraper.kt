package com.example.data.scraper

import android.net.Uri
import android.util.Log
import com.example.data.AppSettings
import com.example.data.model.ChapterItem
import com.example.data.model.MangaDetail
import com.example.data.model.MangaItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import java.net.URLDecoder
import java.net.URLEncoder
import java.security.SecureRandom
import java.security.cert.X509Certificate
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager

object MangaScraper {
    private const val TAG = "MangaScraper"
    val BASE_URL: String
        get() = AppSettings.baseUrl
    private const val USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"

    private val trustAllCertificates = object : X509TrustManager {
        override fun checkClientTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
        override fun checkServerTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
        override fun getAcceptedIssuers(): Array<X509Certificate> = arrayOf()
    }

    private val sslSocketFactory by lazy {
        try {
            val sslContext = SSLContext.getInstance("SSL")
            sslContext.init(null, arrayOf<TrustManager>(trustAllCertificates), SecureRandom())
            sslContext.socketFactory
        } catch (e: Exception) {
            throw RuntimeException(e)
        }
    }

    private fun getDocument(url: String): Document {
         val connection = Jsoup.connect(url)
             .userAgent(USER_AGENT)
             .header("Referer", "$BASE_URL/")
             .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8")
             .header("Accept-Language", "vi-VN,vi;q=0.9,en-US;q=0.8,en;q=0.7")
             .timeout(15000)
             .followRedirects(true)
             .sslSocketFactory(sslSocketFactory)
         
         val savedCookies = AppSettings.cookies
         if (savedCookies.isNotEmpty()) {
             connection.header("Cookie", savedCookies)
         }
         return connection.get()
    }

    suspend fun getLatestManga(page: Int = 1): List<MangaItem> = withContext(Dispatchers.IO) {
        val url = if (page <= 1) BASE_URL else "$BASE_URL/?page=$page"
        try {
            val doc = getDocument(url)
            parseMangaList(doc)
        } catch (e: Exception) {
            Log.e(TAG, "Error fetching latest manga list at page $page", e)
            emptyList()
        }
    }

    suspend fun searchManga(keyword: String, page: Int = 1): List<MangaItem> = withContext(Dispatchers.IO) {
        val encodedKeyword = URLEncoder.encode(keyword, "UTF-8")
        val url = "$BASE_URL/tim-truyen?keyword=$encodedKeyword&page=$page"
        try {
            Log.d(TAG, "Searching manga with URL: $url")
            val doc = getDocument(url)
            var results = parseMangaList(doc)
            
            if (results.isEmpty()) {
                val fallbackUrl1 = "$BASE_URL/tim-kiem?q=$encodedKeyword&page=$page"
                val doc1 = getDocument(fallbackUrl1)
                results = parseMangaList(doc1)
            }
            if (results.isEmpty()) {
                val fallbackUrl2 = "$BASE_URL/?s=$encodedKeyword&page=$page"
                val doc2 = getDocument(fallbackUrl2)
                results = parseMangaList(doc2)
            }
            results
        } catch (e: Exception) {
            Log.e(TAG, "Error searching manga with query: $keyword", e)
            emptyList()
        }
    }

    suspend fun getMangaByCategory(categoryUrl: String, page: Int = 1): List<MangaItem> = withContext(Dispatchers.IO) {
        val url = if (page <= 1) categoryUrl else {
            if (categoryUrl.contains("?")) "$categoryUrl&page=$page" else "$categoryUrl?page=$page"
        }
        try {
            val doc = getDocument(url)
            parseMangaList(doc)
        } catch (e: Exception) {
            Log.e(TAG, "Error loading category page: $url", e)
            emptyList()
        }
    }

    suspend fun getMangaDetail(relativeUrl: String): MangaDetail = withContext(Dispatchers.IO) {
        val fullUrl = if (relativeUrl.startsWith("http")) relativeUrl else "$BASE_URL/$relativeUrl"
        try {
            val doc = getDocument(fullUrl)
            
            // Title
            val title = doc.select("h1.title-detail, h1.entry-title, h1, .post-title h1").text().trim()
            
            // Image Cover
            val imgEl = doc.selectFirst(".detail-info img, .col-image img, .image-info img, .post-thumbnail img, div.image img, .manga-detail img")
            var coverUrl = ""
            if (imgEl != null) {
                coverUrl = imgEl.attr("abs:data-original").ifEmpty {
                    imgEl.attr("abs:data-src").ifEmpty {
                        imgEl.attr("abs:src")
                    }
                }
            }
            if (coverUrl.isEmpty()) {
                coverUrl = doc.select("div.image [src], .detail-info [src]").attr("abs:src")
            }

            // Description / Summary
            var description = doc.select(".detail-content, .summary-content, .entry-content, .story-detail-info, .description-update, .manga-excerpt, .description").text().trim()
            if (description.isEmpty()) {
                description = doc.select("p.summary").text().trim()
            }
            if (description.isEmpty()) {
                description = "Chưa có mô tả cho truyện này."
            }

            var alternativeTitle = ""
            var authors = ""
            var status = ""
            val genres = mutableListOf<String>()
            val detailContainer = doc.selectFirst(".detail-info, .manga-info, .post-content, .manga-detail") ?: doc

            // Try general info layout parsers
            detailContainer.select("li, .post-content_item, .manga-info-item").forEach { li ->
                val label = li.select(".col-xs-4, .name, .title-info, .summary-heading").text().trim().lowercase()
                val valText = li.select(".col-xs-8, .val, .summary-content, a").text().trim()
                
                if (label.contains("tên khác") || label.contains("khác")) {
                    alternativeTitle = valText
                } else if (label.contains("tác giả")) {
                    authors = valText
                } else if (label.contains("tình trạng") || label.contains("trạng thái")) {
                    status = valText
                } else if (label.contains("thể loại") || label.contains("genres")) {
                    li.select("a").forEach { a ->
                        val text = a.text().trim()
                        if (text.isNotEmpty() && !genres.contains(text)) {
                            genres.add(text)
                        }
                    }
                }
            }

            // Extract ratings with recursive multi-fallback robust strategy (Regex over text, Script JSON-LD, and HTML Selectors)
            var ratingAverage = ""
            var ratingCount = ""

            // Method 1: Scan full page text / detail block for "x.y/5" or "x/5" and "y lượt"
            try {
                val pageText = doc.text()
                val ratingRegex = Regex("""(\d+(?:\.\d+)?)\s*/\s*5""")
                val match = ratingRegex.find(pageText)
                if (match != null) {
                    val score = match.groupValues[1]
                    if (score != "0.0" && score != "0") {
                        ratingAverage = score
                        val matchIndex = match.range.first
                        val context = pageText.substring(matchIndex, (matchIndex + 120).coerceAtMost(pageText.length))
                        val countRegex = Regex("""(?:-|–)\s*(\d+)\s*lượt""")
                        val countMatch = countRegex.find(context) ?: Regex("""(\d+)\s*lượt""").find(context)
                        if (countMatch != null) {
                            val countVal = countMatch.groupValues[1]
                            if (countVal != "0") {
                                ratingCount = countVal
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Regex rating parse failed", e)
            }

            // Method 2: Extract from JSON-LD schema (frequently present for Google SEO/Search Console structures)
            if (ratingAverage.isEmpty() || ratingCount.isEmpty()) {
                try {
                    doc.select("script[type*=json]").forEach { script ->
                        val content = script.html()
                        if (ratingAverage.isEmpty()) {
                            val ratingValMatch = Regex("""["']ratingValue["']\s*:\s*["']?(\d+(?:\.\d+)?)["']?""").find(content)
                            if (ratingValMatch != null) {
                                val v = ratingValMatch.groupValues[1]
                                if (v != "0.0" && v != "0") {
                                    ratingAverage = v
                                }
                            }
                        }
                        if (ratingCount.isEmpty()) {
                            val ratingCountMatch = Regex("""["']ratingCount["']\s*:\s*["']?(\d+)["']?""").find(content)
                            if (ratingCountMatch != null) {
                                val c = ratingCountMatch.groupValues[1]
                                if (c != "0") {
                                    ratingCount = c
                                }
                            }
                        }
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "JSON-LD rating parse failed", e)
                }
            }

            // Method 3: Script-based variable scanning (some sites assign ratings directly in jQuery plugins)
            if (ratingAverage.isEmpty() || ratingCount.isEmpty()) {
                try {
                    doc.select("script").forEach { script ->
                        val content = script.html()
                        if (ratingAverage.isEmpty()) {
                            val scoreMatch = Regex("""score\s*:\s*(\d+(?:\.\d+)?)""").find(content)
                            if (scoreMatch != null) {
                                val v = scoreMatch.groupValues[1]
                                if (v != "0.0" && v != "0") {
                                    ratingAverage = v
                                }
                            }
                        }
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Script score rating parse failed", e)
                }
            }

            // Method 4: Classic attribute and BeautifulSoup-style class extraction fallback
            if (ratingAverage.isEmpty()) {
                var rawRatingAvg = doc.select("[itemprop=ratingValue]").attr("content").trim()
                if (rawRatingAvg.isEmpty()) {
                    rawRatingAvg = doc.select("[itemprop=ratingValue]").text().trim()
                }
                if (rawRatingAvg.isEmpty()) {
                    rawRatingAvg = doc.select(".rating-average, .rating-score, .rate-value, .score").text().trim()
                }
                if (rawRatingAvg.isEmpty()) {
                    rawRatingAvg = detailContainer.select(".rating-average, [itemprop=ratingValue]").text().trim()
                }
                if (rawRatingAvg.isNotEmpty()) {
                    val floatMatch = Regex("""\d+(\.\d+)?""").find(rawRatingAvg)?.value
                    if (floatMatch != null) {
                        ratingAverage = floatMatch
                    }
                }
            }

            if (ratingCount.isEmpty()) {
                var rawRatingCount = doc.select("[itemprop=ratingCount]").attr("content").trim()
                if (rawRatingCount.isEmpty()) {
                    rawRatingCount = doc.select("[itemprop=ratingCount]").text().trim()
                }
                if (rawRatingCount.isEmpty()) {
                    rawRatingCount = doc.select(".rating-count, .rate-count, .vote-count").text().trim()
                }
                if (rawRatingCount.isEmpty()) {
                    rawRatingCount = detailContainer.select(".rating-count, [itemprop=ratingCount]").text().trim()
                }
                if (rawRatingCount.isNotEmpty()) {
                    val digitsOnly = Regex("""\d+""").find(rawRatingCount)?.value
                    if (digitsOnly != null) {
                        ratingCount = digitsOnly
                    }
                }
            }

            // Clean fallback defaults if still completely empty so we don't display empty string if parse failed completely
            if (ratingAverage.isEmpty()) ratingAverage = "0.0"
            if (ratingCount.isEmpty()) ratingCount = "0"

            // If empty, extract lists from links inside detail block
            if (genres.isEmpty()) {
                detailContainer.select("a.tr-theloai, a[itemprop=genre], a[href*=/tim-truyen/], a[href*=/the-loai/], a[href*=/genre/]").forEach { a ->
                    val text = a.text().trim()
                    if (text.isNotEmpty() && !text.lowercase().contains("trang chủ") && !text.lowercase().contains("tìm kiếm") && !genres.contains(text)) {
                        genres.add(text)
                    }
                }
            }

            // Extract Chapter links dynamically via AJAX POST if possible, fallback to static if not
            val storyIdInput = doc.getElementById("storyID")
            val storyId = storyIdInput?.attr("value") ?: ""
            val chapters = mutableListOf<ChapterItem>()

            if (storyId.isNotEmpty()) {
                try {
                    val connection = Jsoup.connect("$BASE_URL/Story/ListChapterByStoryID")
                        .userAgent(USER_AGENT)
                        .header("Referer", fullUrl)
                        .header("Accept", "*/*")
                        .header("X-Requested-With", "XMLHttpRequest")
                        .data("StoryID", storyId)
                        .timeout(15000)
                    
                    val savedCookies = AppSettings.cookies
                    if (savedCookies.isNotEmpty()) {
                        connection.header("Cookie", savedCookies)
                    }
                    val chapterHtmlDoc = connection.post()

                    val chapterElements = chapterHtmlDoc.select("a")
                    chapterElements.forEach { a ->
                        val href = a.attr("abs:href").ifEmpty {
                            val relativePath = a.attr("href")
                            if (relativePath.startsWith("/")) "$BASE_URL$relativePath" else relativePath
                        }
                        val name = a.text().trim()
                        val nameLower = name.lowercase()
                        if (nameLower.contains("xem thêm") || nameLower.contains("thu gọn") || nameLower.contains("xem tiếp") || nameLower.contains("đọc tiếp") || href.startsWith("javascript:") || href.endsWith("#") || href.isBlank()) {
                            return@forEach
                        }
                        if (href.isNotEmpty() && name.isNotEmpty()) {
                            val parentLi = a.parent()
                            val timeText = parentLi?.select(".col-xs-4, .time, .uploaded-at")?.text()?.trim() ?: ""
                            
                            if (chapters.none { it.url == href }) {
                                chapters.add(ChapterItem(
                                    url = href,
                                    name = name,
                                    uploadedAt = timeText
                                ))
                            }
                        }
                    }
                } catch (ajaxError: Exception) {
                    Log.e(TAG, "Error fetching dynamic chapter list via POST", ajaxError)
                }
            }

            // Fallback: original static scraper
            if (chapters.isEmpty()) {
                val cleanSlug = relativeUrl.substringAfter("truyen-tranh/").substringBefore("/")
                val chapterElements = doc.select("a[href*=/chapter-], a[href*=/chap-], .list-chapter a, .chapters a")

                chapterElements.forEach { a ->
                    val href = a.attr("abs:href")
                    val name = a.text().trim()
                    val nameLower = name.lowercase()
                    if (nameLower.contains("xem thêm") || nameLower.contains("thu gọn") || nameLower.contains("xem tiếp") || nameLower.contains("đọc tiếp") || href.startsWith("javascript:") || href.endsWith("#") || href.isBlank()) {
                        return@forEach
                    }
                    if (href.isNotEmpty() && (cleanSlug.isEmpty() || href.contains(cleanSlug))) {
                        val parentLi = a.parent()
                        val timeText = parentLi?.select(".col-xs-4, .time, .uploaded-at")?.text()?.trim() ?: ""
                        
                        if (chapters.none { it.url == href }) {
                            chapters.add(ChapterItem(
                                url = href,
                                name = name,
                                uploadedAt = timeText
                            ))
                        }
                    }
                }
            }

            // Sort chapters chronologically:
            // Usually scraped top-down (newest first). Let's make sure they are ordered properly
            MangaDetail(
                url = fullUrl,
                title = title.ifEmpty { "Chưa cập nhật tên truyện" },
                coverUrl = coverUrl,
                description = description,
                alternativeTitle = alternativeTitle,
                authors = authors.ifEmpty { "Chưa rõ" },
                status = status.ifEmpty { "Chưa cập nhật" },
                genres = genres,
                chapters = chapters,
                ratingAverage = ratingAverage,
                ratingCount = ratingCount
            )
        } catch (e: Exception) {
            Log.e(TAG, "Error loading details for $relativeUrl", e)
            throw e
        }
    }

    suspend fun getChapterImages(chapterUrl: String): List<String> = withContext(Dispatchers.IO) {
        val fullUrl = if (chapterUrl.startsWith("http")) chapterUrl else "$BASE_URL/$chapterUrl"
        try {
            val doc = getDocument(fullUrl)
            val list = mutableListOf<String>()

            // Extract image nodes inside traditional reader blocks
            val imgElements = doc.select(".reading-detail img, .page-chapter img, .chapter-content img, .vung-doc img, .box-read img, .chapter-video-frame img")
            imgElements.forEach { img ->
                var src = img.attr("abs:data-original")
                if (src.isEmpty()) src = img.attr("abs:data-src")
                if (src.isEmpty()) src = img.attr("abs:src")
                if (src.isEmpty()) src = img.attr("abs:data-lazy-src")
                
                if (src.isNotEmpty() && !src.contains("logo") && !src.contains("banner") && !src.contains("icon")) {
                    list.add(src)
                }
            }

            // Fallback: If list is empty, search more broadly inside any div that likely contains pages
            if (list.isEmpty()) {
                doc.select("img").forEach { img ->
                    var src = img.attr("abs:data-original")
                    if (src.isEmpty()) src = img.attr("abs:src")
                    if (src.isNotEmpty() && (src.contains("upload") || src.contains("chapter") || src.contains("truyen") || src.contains("cdn") || src.contains("manga"))) {
                        if (!src.contains("logo") && !src.contains("banner") && !list.contains(src)) {
                            list.add(src)
                        }
                    }
                }
            }
            list
        } catch (e: Exception) {
            Log.e(TAG, "Error fetching images for chapter: $chapterUrl", e)
            emptyList()
        }
    }

    // Common list extractor with fallbacks
    private fun parseMangaList(doc: Document): List<MangaItem> {
        val items = mutableListOf<MangaItem>()
        
        // Grab traditional grids
        var elements = doc.select(".items .item, .list-stories .item, div.item, .thumb-item-flow, .story-item, .card-manga, .manga-item-card")
        
        if (elements.isEmpty()) {
            elements = doc.select("div:has(a[href*=/truyen-tranh/]):has(img)")
        }

        for (element in elements) {
            // Check if element is inside a slider/carousel or sidebar to exclude them
            var isInsideSliderOrSidebar = false
            var parentCheck = element.parent()
            while (parentCheck != null) {
                if (parentCheck.`is`(".items-slide, .recommend-comics, .featured-comics, .top-comics, #slider, .col-sidebar, #ctl00_divRight, .right-side, .rightCol, #right-side")) {
                    isInsideSliderOrSidebar = true
                    break
                }
                parentCheck = parentCheck.parent()
            }
            if (isInsideSliderOrSidebar) {
                continue
            }

            val linkEl = element.selectFirst("a[href*=/truyen-tranh/]:not([href*=/chapter-]):not([href*=/chap-])") ?: continue
            val href = linkEl.attr("abs:href")
            
            var title = linkEl.text().trim()
            if (title.isEmpty()) {
                title = element.select("h3, h4, .title, .manga-title").text().trim()
            }
            if (href.isEmpty() || title.isEmpty()) continue

            val imgEl = element.selectFirst("img")
            var coverUrl = ""
            if (imgEl != null) {
                coverUrl = imgEl.attr("abs:data-original")
                if (coverUrl.isEmpty()) coverUrl = imgEl.attr("abs:data-src")
                if (coverUrl.isEmpty()) coverUrl = imgEl.attr("abs:src")
                if (coverUrl.isEmpty()) coverUrl = imgEl.attr("abs:data-lazy-src")
            }

            val chapEl = element.selectFirst("a[href*=/chapter-], a[href*=/chap-]")
            val latestChap = chapEl?.text()?.trim() ?: ""

            var rating = element.select(".rating-badge").text().trim()
            if (rating.isEmpty()) {
                rating = element.select(".rating, .score, .star, .star-rating").text().trim()
            }
            
            var views = ""
            val viewEl = element.selectFirst(".view.clearfix, .view")
            if (viewEl != null) {
                val spanEl = viewEl.selectFirst("span")
                views = if (spanEl != null) spanEl.text().trim() else viewEl.text().trim()
            }
            if (views.isEmpty()) {
                views = element.select(".views, .view-count").text().trim()
            }

            if (items.none { it.url == href }) {
                items.add(MangaItem(
                    url = href,
                    title = title,
                    coverUrl = coverUrl,
                    rating = rating,
                    views = views,
                    latestChapter = latestChap
                ))
            }
        }

        // Extreme fallback fallback: search all valid tags inside page
        if (items.isEmpty()) {
            val links = doc.select("a[href*=/truyen-tranh/]:not([href*=/chapter-]):not([href*=/chap-])")
            for (link in links) {
                var isInsideSliderOrSidebar = false
                var parentCheck = link.parent()
                while (parentCheck != null) {
                    if (parentCheck.`is`(".items-slide, .recommend-comics, .featured-comics, .top-comics, #slider, .col-sidebar, #ctl00_divRight, .right-side, .rightCol, #right-side")) {
                        isInsideSliderOrSidebar = true
                        break
                    }
                    parentCheck = parentCheck.parent()
                }
                if (isInsideSliderOrSidebar) continue

                val href = link.attr("abs:href")
                val title = link.text().trim()
                if (href.isNotEmpty() && title.isNotEmpty()) {
                    val imgEl = link.parent()?.selectFirst("img") ?: link.parent()?.parent()?.selectFirst("img")
                    var coverUrl = ""
                    if (imgEl != null) {
                        coverUrl = imgEl.attr("abs:data-original").ifEmpty { imgEl.attr("abs:src") }
                    }
                    if (items.none { it.url == href }) {
                        items.add(MangaItem(url = href, title = title, coverUrl = coverUrl))
                    }
                }
            }
        }

        return items
    }

    // Standard list of built-in categories / genres retrieved dynamically
    suspend fun getAvailableGenres(): List<Pair<String, String>> = withContext(Dispatchers.IO) {
        val defaultGenres = listOf(
            "Action" to "$BASE_URL/tim-truyen/action",
            "Cổ Đại" to "$BASE_URL/tim-truyen/co-dai",
            "Comedy" to "$BASE_URL/tim-truyen/comedy",
            "Chuyển Sinh" to "$BASE_URL/tim-truyen/chuyen-sinh",
            "Drama" to "$BASE_URL/tim-truyen/drama",
            "Fantasy" to "$BASE_URL/tim-truyen/fantasy",
            "Harem" to "$BASE_URL/tim-truyen/harem",
            "Manga" to "$BASE_URL/tim-truyen/manga",
            "Manhua" to "$BASE_URL/tim-truyen/manhua",
            "Manhwa" to "$BASE_URL/tim-truyen/manhwa",
            "Romance" to "$BASE_URL/tim-truyen/romance",
            "Shounen" to "$BASE_URL/tim-truyen/shounen",
            "Supernatural" to "$BASE_URL/tim-truyen/supernatural",
            "Học Đường" to "$BASE_URL/tim-truyen/hoc-duong",
            "Học Viện" to "$BASE_URL/tim-truyen/hoc-vien",
            "Kinh Dị" to "$BASE_URL/tim-truyen/kinh-di",
            "HOT" to "$BASE_URL/tim-truyen/hot",
            "Truyện Màu" to "$BASE_URL/tim-truyen/truyen-mau"
        )
        try {
            val doc = getDocument(BASE_URL)
            val scrapedGenres = mutableListOf<Pair<String, String>>()
            doc.select("a[href*=/tim-truyen/], a[href*=/tim-truyen]").forEach { a ->
                val name = a.text().trim()
                val href = a.attr("abs:href")
                if (name.isNotEmpty() && href.isNotEmpty() && !href.contains("keyword") && !href.contains("?")) {
                    val slugPart = href.substringAfter("/tim-truyen").removePrefix("/")
                    if (slugPart.isNotEmpty() && scrapedGenres.none { it.first.lowercase() == name.lowercase() }) {
                        scrapedGenres.add(name to href)
                    }
                }
            }
            if (scrapedGenres.isNotEmpty()) scrapedGenres else defaultGenres
        } catch (e: Exception) {
            Log.e(TAG, "Error scraping live genres list, using defaults", e)
            defaultGenres
        }
    }

    suspend fun checkLoginStatus(): String = withContext(Dispatchers.IO) {
        val savedCookies = AppSettings.cookies
        var parsedUser = ""
        if (savedCookies.isNotEmpty()) {
            try {
                // Parse standard semicolon-separated cookies
                val parts = savedCookies.split(";").map { it.trim() }
                val loginToken = parts.find { it.startsWith("LoginToken=", ignoreCase = true) || it.startsWith("logintoken=", ignoreCase = true) }
                val truyenAuth = parts.find { it.contains("truyen_AUTH=", ignoreCase = true) || it.contains("auth=", ignoreCase = true) }
                val aspxAuth = parts.find { it.contains("ASPXAUTH=", ignoreCase = true) }
                
                if (loginToken != null) {
                    val value = loginToken.substringAfter("=").trim()
                    if (value.isNotEmpty() && value != "null" && value != "undefined") {
                        parsedUser = value
                    }
                }
                
                if (parsedUser.isEmpty() && (truyenAuth != null || aspxAuth != null)) {
                    parsedUser = "Đại Hiệp (Cookie)"
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error parsing offline cookies", e)
            }
        }

        try {
            val doc = getDocument(BASE_URL)
            // Look for any logout URL references
            val logoutEl = doc.select("a[href*=/Account/Logout], a[href*=/Logout], a[href*=dang-xuat], a[href*=Logout]")
            if (logoutEl.isEmpty()) {
                // If the logout link is missing in HTML, but we have offline cookies indicating login, trust the cookies!
                return@withContext parsedUser
            }
            
            // Logged in! Find user display name
            val nameEl = doc.selectFirst(".member-name, .user-name, .username, .name, a[href*=/Account/MemberInfo], a[href*=/thanh-vien/], .login-display")
            var userName = nameEl?.text()?.trim() ?: ""
            if (userName.isEmpty()) {
                userName = doc.select(".user-menu, .profile, .member").text().trim()
            }
            if (userName.isEmpty()) {
                userName = parsedUser
            }
            if (userName.length > 30) {
                userName = userName.take(30) + "..."
            }
            userName.ifEmpty { "Đại Hiệp" }
        } catch (e: Exception) {
            Log.e(TAG, "Error checking login status via network, falling back to parsed cookie", e)
            parsedUser
        }
    }
}
