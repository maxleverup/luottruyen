package com.example.data

import android.content.Context
import android.content.SharedPreferences

object AppSettings {
    private const val PREFS_NAME = "manga_app_settings"
    private const val KEY_BASE_URL = "base_url"
    private const val KEY_COOKIES = "session_cookies"
    private const val KEY_USER_NAME = "logged_in_user_name"
    private const val KEY_READER_SLUG = "reader_last_slug"
    private const val KEY_READER_CHAPTER_URL = "reader_last_chapter_url"
    private const val KEY_READER_PAGE_INDEX = "reader_last_page_index"
    private const val KEY_FILTER_MIN_RATING = "filter_min_rating"
    private const val KEY_FILTER_MIN_CHAP = "filter_min_chap"
    private const val KEY_FILTER_GENRES = "filter_selected_genres"
    private const val DEFAULT_BASE_URL = "https://luottruyen6.com"

    private lateinit var prefs: SharedPreferences

    fun init(context: Context) {
        prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    var baseUrl: String
        get() = prefs.getString(KEY_BASE_URL, DEFAULT_BASE_URL) ?: DEFAULT_BASE_URL
        set(value) {
            val url = if (value.endsWith("/")) value.removeSuffix("/") else value
            prefs.edit().putString(KEY_BASE_URL, url).apply()
        }

    var cookies: String
        get() = prefs.getString(KEY_COOKIES, "") ?: ""
        set(value) {
            val cleaned = value
                .replace("\r", "")
                .replace("\n", "")
                .split(";")
                .map { it.trim() }
                .filter { it.isNotEmpty() }
                .joinToString("; ")
            prefs.edit().putString(KEY_COOKIES, cleaned).apply()
        }

    var loggedInUserName: String
        get() = prefs.getString(KEY_USER_NAME, "") ?: ""
        set(value) {
            prefs.edit().putString(KEY_USER_NAME, value).apply()
        }

    /**
     * Lưu vị trí đọc tức thì bằng commit() — không bị mất khi app bị kill đột ngột.
     * Gọi mỗi khi user scroll, không cần coroutine.
     */
    fun saveReaderPosition(slug: String, chapterUrl: String, pageIndex: Int) {
        prefs.edit()
            .putString(KEY_READER_SLUG, slug)
            .putString(KEY_READER_CHAPTER_URL, chapterUrl)
            .putInt(KEY_READER_PAGE_INDEX, pageIndex)
            .commit() // commit() thay vì apply() — đồng bộ, ghi ngay, an toàn khi kill app
    }

    fun getReaderPosition(): Triple<String, String, Int>? {
        val slug = prefs.getString(KEY_READER_SLUG, "") ?: ""
        val chapterUrl = prefs.getString(KEY_READER_CHAPTER_URL, "") ?: ""
        val pageIndex = prefs.getInt(KEY_READER_PAGE_INDEX, 0)
        return if (slug.isNotEmpty() && chapterUrl.isNotEmpty()) Triple(slug, chapterUrl, pageIndex) else null
    }

    fun clearReaderPosition() {
        prefs.edit()
            .remove(KEY_READER_SLUG)
            .remove(KEY_READER_CHAPTER_URL)
            .remove(KEY_READER_PAGE_INDEX)
            .apply()
    }

    // --- Bộ lọc ---

    var filterMinRating: Float
        get() = prefs.getFloat(KEY_FILTER_MIN_RATING, 0f)
        set(value) { prefs.edit().putFloat(KEY_FILTER_MIN_RATING, value).apply() }

    var filterMinChap: Int
        get() = prefs.getInt(KEY_FILTER_MIN_CHAP, 0)
        set(value) { prefs.edit().putInt(KEY_FILTER_MIN_CHAP, value).apply() }

    // Lưu danh sách thể loại đã chọn dưới dạng chuỗi phân cách bởi "|"
    var filterSelectedGenres: Set<String>
        get() {
            val raw = prefs.getString(KEY_FILTER_GENRES, "") ?: ""
            return if (raw.isEmpty()) emptySet() else raw.split("|").toSet()
        }
        set(value) {
            prefs.edit().putString(KEY_FILTER_GENRES, value.joinToString("|")).apply()
        }

    fun resetFilters() {
        prefs.edit()
            .remove(KEY_FILTER_MIN_RATING)
            .remove(KEY_FILTER_MIN_CHAP)
            .remove(KEY_FILTER_GENRES)
            .apply()
    }
}
