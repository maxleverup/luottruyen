package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.ui.Modifier
import androidx.navigation.compose.rememberNavController
import com.example.data.db.MangaDatabase
import com.example.data.repository.MangaRepository
import com.example.ui.navigation.AppNavGraph
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Enable edge-to-edge display mode natively
        enableEdgeToEdge()
        
        // Initialize local settings
        com.example.data.AppSettings.init(this)
        
        // Initialize Room Database and Repository
        val database = MangaDatabase.getDatabase(this)
        val repository = MangaRepository(
            favoriteDao = database.favoriteDao(),
            historyDao = database.historyDao(),
            cachedDetailDao = database.cachedDetailDao(),
            readChapterDao = database.readChapterDao()
        )

        setContent {
            MyApplicationTheme {
                val navController = rememberNavController()
                
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    contentWindowInsets = androidx.compose.foundation.layout.WindowInsets(0, 0, 0, 0) // Handle fully in screen layers
                ) { innerPadding ->
                    AppNavGraph(
                        navController = navController,
                        repository = repository,
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }
}
